<!doctype html>
<html class="no-js" lang="en">


@include("include/head")


<body>

    @include("include/header")

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Shopping Cart</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->
    <!--shopping cart area start -->
    <div class="cart_page_bg">
        <div class="container">
            <div class="shopping_cart_area">
                <div class="row">
                    <div class="col-12">
                        <div class="table_desc">
                            <div class="cart_page">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product_remove">Delete</th>
                                            <th class="product_thumb">Image</th>
                                            <th class="product_name">Product</th>
                                            <th class="product_variant">Variant</th>
                                            <th class="product-price">Price</th>
                                            <th class="product_quantity">Quantity</th>
                                            <th class="product_total">Total</th>
                                            <th class="product_update">Update</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($cart as $item)
                                        <tr>
                                            <td class="product_remove">
                                                <form id="delete-form-{{ $item->id }}" action="{{ route('cart.delete', $item->id) }}" method="GET" style="display: inline;">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="bg-danger text-white" type="submit"><i class="fa fa-trash-o"></i></button>
                                                </form>
                                            </td>
                                            <td class="product_thumb">
                                                <a href="{{ route('product.show', $item->product->url) }}">
                                                    <img src="{{ asset($item->variant ? $item->variant->variantImages->first()->image_url : $item->product->images->first()->image_url) }}" alt="{{ $item->product->product_name }}">
                                                </a>
                                            </td>
                                            <td class="product_name">
                                                <a href="{{ route('product.show', $item->product->url) }}">{{ $item->product->product_name }}</a>
                                            </td>
                                            <td class="product_variant">
                                                <label>Variant</label>
                                                <p>{{ $item->variant ? $item->variant->variant : 'Default' }}</p>
                                            </td>
                                            <td class="product-price">
                                                INR {{ $item->variant ? $item->variant->sale_price : $item->product->sale_price }}
                                            </td>
                                            <form action="{{ route('cart.update') }}" method="POST">
                                                @csrf
                                                <td class="product_quantity">
                                                    <label>Quantity</label>
                                                    <input
                                                        min="{{ $item->product->mrp < 400 ? 3 : 1 }}"
                                                        max="100"
                                                        name="quantity"
                                                        value="{{ $item->product->mrp < 400 && $item->quantity < 3 ? 3 : $item->quantity }}"
                                                        type="number">
                                                    <input type="hidden" name="id" value="{{ $item->id }}" />
                                                    <input type="hidden" name="product_id" value="{{ $item->product->id }}" />
                                                </td>
                                                <td class="product_total">
                                                    INR {{ ($item->variant ? $item->variant->sale_price : $item->product->sale_price) * $item->quantity }}
                                                </td>
                                                <td class="product_update">
                                                    <button type="submit">Update</button>
                                                </td>
                                            </form>

                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="8">Your cart is empty.</td>
                                        </tr>
                                        @endforelse

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="coupon_area">
                    <div class="row">


                        <div class="col-lg-6 col-md-6">
                            <div class="coupon_code right">
                                <div class="coupon_inner">
                                    <!-- Display coupon applied message if a coupon is used -->
                                    <div class="cart_subtotal">
                                        <p>Subtotal</p>
                                        <p class="cart_amount">INR {{ $cartTotal }}</p>
                                    </div>
                                    <div class="checkout_btn">
                                        <a href="/checkout">Proceed to Checkout</a>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--shopping cart area end -->

    @include("include/footer")

</body>

</html>