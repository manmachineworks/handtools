<!doctype html>
<html class="no-js" lang="en">
@include("include/head")

<body>

    @include("include/header")
    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>{{ $product->product_name }}</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->
    <div class="product_page_bg">
        <div class="container">
            <!--product details start-->

        </div>
        <!--product info end-->

        <!--product area start-->
        <section class="product_area related_products">
            <div class="product_details">
                <div class="row">
                    <div class="col-lg-5 col-md-6">
                        <div class="product-details-tab">
                            <div id="img-1" class="zoomWrapper single-zoom">
                                <a href="#">
                                    <img id="zoom1" src="{{ asset($productImages->first()->image_url) }}" data-zoom-image="{{ asset($productImages->first()->image_url) }}" alt="{{ $product->product_name }}">
                                </a>
                            </div>
                            <div class="single-zoom-thumb">
                                <ul class="s-tab-zoom owl-carousel single-product-active" id="gallery_01">
                                    @foreach($productImages as $image)
                                    <li>
                                        <a href="#" class="elevatezoom-gallery" data-image="{{ asset($image->image_url) }}" data-zoom-image="{{ asset($image->image_url) }}">
                                            <img src="{{ asset($image->image_url) }}" alt="{{ $product->product_name }}" />
                                        </a>
                                    </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-6">
                        <div class="product_d_right">

                            <h3><a href="#"><span id="varaint_name">{{ $product->product_name }}</span></a></h3>
                            <div class="product_rating">
                                <ul>
                                    @for ($i = 1; $i <= 5; $i++) <li>
                                        <a href="#">
                                            @if ($i <= $averageRating) <i class="ion-android-star"></i>
                                                @else
                                                <i class="ion-android-star-outline"></i>
                                                @endif
                                        </a>
                                        </li>
                                        @endfor
                                        <li class="review"><a href="#">({{ $reviews->count() }} customer review{{ $reviews->count() > 1 ? 's' : '' }})</a></li>
                                </ul>
                            </div>
                            <div class="price_box">
                                <span class="old_price">Rs <span id="old_price">{{ $product->mrp }}</span></span>
                                <span class="current_price">Rs <span id="current_price">{{ $product->sale_price }}
                                    </span>
                                    <span class="stock" id="stock">
                                        @if($product->stock == 0)
                                        <p class="text-danger">Out of Stock</p>
                                        @else
                                        <p class="text-success">In Stock</p>
                                        @endif
                                    </span>

                                    <span class="delivery_time" id="delivery_time">
                                        Estimated delivery in {{ $product->delivery_time }}
                                    </span>
                            </div>
                            <div class="product_desc">
                                <p>{!! Str::limit($product->description, 250) !!}</p>
                            </div>
                            <div class="product_variant color">
                                <form action="{{ route('cart.add', ['id' => $product->id]) }}" method="GET">
                                    <!-- Product ID (hidden) -->
                                    <input type="hidden" name="product_id" value="{{ $product->id }}">

                                    <!-- Variant ID (hidden) -->
                                    <input type="hidden" id="selected_variant" name="variant_id" value="">


                                    <ul>
                                        @foreach($productVariants as $variant)
                                        @if($variant->variant != '1 liter' && $variant->variant != '5 liter')
                                        <li class="color1 m-2 mb-4">
                                            <button type="button" class="btn btn-danger variant-selector" data-variant-id="{{ $variant->id }}">
                                                {{ $variant->variant }}
                                            </button>
                                        </li>
                                        @endif
                                        @endforeach
                                    </ul>
                                    <div class="product_variant quantity">
                                        <label>Quantity</label>
                                        <input
                                            min="{{ $product->mrp < 400 ? 3 : 1 }}"
                                            max="100"
                                            value="{{ $product->mrp < 400 ? 3 : 1 }}"
                                            type="number"
                                            name="quantity">
                                        <button class="button" type="submit">Add to Cart</button>
                                    </div>
                                </form>
                                @if($product->mrp < 400)
                                    <div class="text-danger">This product requires a minimum order quantity of 3 for purchase.
                            </div>
                            @endif
                        </div>

                        <div class="product_d_action">
                            <ul>
                                <li><a href="{{ route('wishlist.add', $product->id) }}" title="Add to wishlist">+ Add to Wishlist</a></li>
                            </ul>
                        </div>

                        <div class="product_d_meta">
                            <span>SKU: <span id="sku_code">{{ $product->sku_code }}</span></span>
                            <span>Category: <a href="#">{{ $product->category->name }}</a></span>
                            <!-- <span>Tags:
                                    <a href="#">Creams</a>
                                    <a href="#">Lotions</a>
                                </span> -->

                        </div>
                        <div class="priduct_social">
                            <ul>
                                <li>
                                    <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=https://www.mafraindia.com/product/{{ $product->url }}" title="Facebook" target="_blank">
                                        <i class="fa fa-facebook"></i> Like
                                    </a>
                                </li>
                                <li>
                                    <a class="twitter" href="https://twitter.com/intent/tweet?url=https://www.mafraindia.com/product/{{ $product->url }}&text=YOUR_TEXT" title="Twitter" target="_blank">
                                        <i class="fa fa-twitter"></i> Tweet
                                    </a>
                                </li>
                                <li>
                                    <a class="pinterest" href="https://pinterest.com/pin/create/button/?url=https://www.mafraindia.com/product/{{ $product->url }}&media=YOUR_IMAGE&description=YOUR_DESCRIPTION" title="Pinterest" target="_blank">
                                        <i class="fa fa-pinterest"></i> Save
                                    </a>
                                </li>
                                <li>
                                    <a class="google-plus" href="https://plus.google.com/share?url=https://www.mafraindia.com/product/{{ $product->url }}" title="Google+" target="_blank">
                                        <i class="fa fa-google-plus"></i> Share
                                    </a>
                                </li>
                                <li>
                                    <a class="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&https://www.mafraindia.com/product/{{ $product->url }}=YOUR_URL&title=YOUR_TITLE&summary=YOUR_SUMMARY&source=YOUR_SOURCE" title="LinkedIn" target="_blank">
                                        <i class="fa fa-linkedin"></i> Linked
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
    </div>

    <div class="product_d_info">
        <div class="row">
            <div class="col-12">
                <div class="product_d_inner">
                    <div class="product_info_button">
                        <ul class="nav" role="tablist" id="nav-tab">
                            <li>
                                <a class="active" data-bs-toggle="tab" href="#info" role="tab" aria-controls="info" aria-selected="false">Description</a>
                            </li>
                            <!-- <li>
                                        <a data-bs-toggle="tab" href="#sheet" role="tab" aria-controls="sheet" aria-selected="false">Specification</a>
                                    </li> -->
                            <li>
                                <a data-bs-toggle="tab" href="#reviews" role="tab" aria-controls="reviews" aria-selected="false">Reviews ({{ $reviews->count() }})</a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="info" role="tabpanel">
                            <div class="product_info_content">
                                <p>{!! $product->description !!}</p>
                            </div>
                        </div>
                        <!-- <div class="tab-pane fade" id="sheet" role="tabpanel">
                                    <div class="product_d_table">
                                        <form action="#">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td class="first_child">Compositions</td>
                                                        <td>Polyester</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="first_child">Styles</td>
                                                        <td>Girly</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="first_child">Properties</td>
                                                        <td>Short Dress</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                    <div class="product_info_content">
                                        <p>Fashion has been creating well-designed collections since 2010. The brand offers
                                            feminine designs delivering stylish separates and statement dresses which have since
                                            evolved into a full ready-to-wear collection in which every item is a vital part of
                                            a woman's wardrobe. The result? Cool, easy, chic looks with youthful elegance and
                                            unmistakable signature style. All the beautiful pieces are made in Italy and
                                            manufactured with the greatest attention. Now Fashion extends to a range of
                                            accessories including shoes, hats, belts and more!</p>
                                    </div>
                                </div> -->

                        <div class="tab-pane fade" id="reviews" role="tabpanel">
                            <div class="reviews_wrapper">

                                <h2>{{ $reviews->count() }} review(s) for {{ $product->product_name }}</h2>
                                @foreach($reviews as $review)
                                <div class="reviews_comment_box">
                                    <div class="comment_text">
                                        <div class="reviews_meta">
                                            <div class="product_rating">
                                                <ul>
                                                    @for ($i = 0; $i < $review->rating; $i++)
                                                        <li><a href="#"><i class="fa fa-star" aria-hidden="true"></i></a></li>
                                                        @endfor
                                                        @for ($i = $review->rating; $i < 5; $i++) <li><a href="#"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
                                                            @endfor
                                                </ul>
                                            </div>
                                            <p><strong>{{ $review->user_name }} </strong> - {{ $review->created_at->format('F d, Y') }}</p>
                                            <span>{{ $review->comment }}</span>
                                        </div>
                                    </div>
                                </div>
                                @endforeach
                                <div class="comment_title">
                                    <h2>Add a review </h2>
                                    <p>Your email address will not be published. Required fields are marked </p>
                                </div>

                                <div class="product_review_form">
                                    <form action="{{ route('product.review.store', ['id' => $product->id]) }}" method="POST">
                                        @csrf
                                        <div class="row">
                                            <div class="col-12">
                                                <label for="review_comment">Your review *</label>
                                                <textarea name="comment" id="review_comment" required>{{ old('comment') }}</textarea>
                                                @error('comment')
                                                <div class="alert alert-danger">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="col-lg-6 col-md-6">
                                                <label for="author">Name *</label>
                                                <input id="author" type="text" name="user_name" value="{{ old('user_name') }}" required>
                                                @error('user_name')
                                                <div class="alert alert-danger">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="col-lg-6 col-md-6">
                                                <label for="email">Email *</label>
                                                <input id="email" type="email" name="user_email" value="{{ old('user_email') }}" required>
                                                @error('user_email')
                                                <div class="alert alert-danger">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="col-4">
                                                <label for="rating">Your rating *</label>
                                                <select name="rating" id="rating" class="form-control" required>
                                                    <option value="5" {{ old('rating') == 5 ? 'selected' : '' }}>5</option>
                                                    <option value="4" {{ old('rating') == 4 ? 'selected' : '' }}>4</option>
                                                    <option value="3" {{ old('rating') == 3 ? 'selected' : '' }}>3</option>
                                                    <option value="2" {{ old('rating') == 2 ? 'selected' : '' }}>2</option>
                                                    <option value="1" {{ old('rating') == 1 ? 'selected' : '' }}>1</option>
                                                </select>
                                                @error('rating')
                                                <div class="alert alert-danger mt-2">{{ $message }}</div>
                                                @enderror
                                            </div>

                                        </div>
                                        <button type="submit">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
    <!--product area end-->

    <!--product area end-->
    <div class="container-fluid">
        <section class="product_area related_products p-4">
            <div class="row">
                <div class="col-12">
                    <div class="section_title title_style2">
                        <div class="title_content">
                            <h2><span>Related</span> Products</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="product_carousel product_column4 owl-carousel">
                    @foreach($relatedProducts as $product)
                    <div class="col-lg-3">
                        <div class="product_items">
                            <article class="single_product">
                                <figure>
                                    <div class="product_thumb">
                                        <a class="primary_img" href="{{ url('product/' . $product->url) }}">
                                            @if($product->images->isNotEmpty())
                                            <img src="{{ asset($product->images->first()->image_url) }}" alt="">
                                            @else
                                            <img src="default_image_path.jpg" alt="">
                                            @endif
                                        </a>
                                        @if($product->images->count() > 1)
                                        <a class="secondary_img" href="{{ url('product/' . $product->url) }}">
                                            <img src="{{ asset($product->images->get(1)->image_url) }}" alt="" height="200px">
                                        </a>
                                        @endif
                                        <div class="label_product">
                                            @if($product->mrp > $product->sale_price)
                                            @php
                                            $discount = (($product->mrp - $product->sale_price) / $product->mrp) * 100;
                                            @endphp
                                            <span class="label_sale">-{{ round($discount) }}%</span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="product_content">
                                        <div class="product_content_inner">

                                            <h4 class="product_name"><a href="{{ url('product/' . $product->url) }}">{{
                                            $product->product_name }}</a></h4>
                                            <div class="product_rating">
                                                <ul>
                                                    <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                    <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                    <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                    <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                    <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                </ul>
                                            </div>
                                            <div class="price_box">
                                                <span class="old_price">Rs {{ $product->mrp }}</span>
                                                <span class="current_price">Rs {{ $product->sale_price }}</span>
                                            </div>
                                        </div>
                                        <div class="action_links">
                                            <ul>
                                                <li class="add_to_cart"><a href="{{ route('cart.add', $product->id) }}" title="Add to cart">Add to
                                                        cart</a></li>
                                                <li class="wishlist"><a href="{{ route('wishlist.add', $product->id) }}" title="Add to Wishlist"><i class="icon-heart"></i></a></li>

                                            </ul>
                                        </div>
                                    </div>
                                </figure>
                            </article>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

        </section>
    </div>
    </div>
    @include("include/footer")
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.variant-selector').forEach(button => {
                button.addEventListener('click', () => {
                    const variantId = button.getAttribute('data-variant-id');
                    document.getElementById('selected_variant').value = variantId;

                    fetch(`/product/variant/${variantId}`)
                        .then(response => response.json())
                        .then(data => {
                            // Update product prices and SKU
                            document.getElementById('current_price').textContent = data.sale_price;
                            document.getElementById('sku_code').textContent = data.sku_code;
                            document.getElementById('varaint_name').textContent = data.varaint_name;

                            const stockElement = document.getElementById('stock');
                            if (data.stock == 0) {
                                stockElement.innerHTML = '<p class="text-danger">Out of Stock</p>';
                            } else {
                                stockElement.innerHTML = '<p class="text-success">In Stock</p>';
                            }

                            // Update the product images in the carousel
                            const carousel = $('#variant-images-carousel');
                            const newImagesHtml = data.images.map(image => `
                        <div class="item">
                            <div class="top-img">
                                <img id="zoom1" src="${image.image_url}" data-zoom-image="{{ asset($productImages->first()->image_url) }}" alt="${data.variant}">
                            </div>
                        </div>
                    `).join('');

                            // Replace the carousel content and refresh it
                            carousel.trigger('replace.owl.carousel', newImagesHtml).trigger('refresh.owl.carousel');

                            // Reinitialize the zoom functionality for the new images
                            $('#zoom1').elevateZoom({
                                zoomType: "inner",
                                cursor: "crosshair"
                            });
                        })
                        .catch(error => console.error('Error fetching variant data:', error));
                });
            });
        });
    </script>
    <script>
        @if(!empty($product))
        const product = @json($product); // Product data as a JS object

        gtag("event", "view_item", {
            currency: "USD",
            value: 30.03,
            items: [{
                item_id: product.id.toString(),
                item_name: product.product_name,
                index: 0,
                item_brand: "Mafra India",
                item_category: product.category ? product.category.name : null,
                item_list_id: "related_products",
                item_list_name: "Related Products",
                price: parseFloat(product.sale_price),
                quantity: 1
            }]
        });
        @endif
    </script>




</body>

</html>