<!doctype html>
<html class="no-js" lang="en">
@include("include/head")

<body>
    @include("include/header")

    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>ppf-terms</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Privacy Policy area start-->
    <div class="privacy_policy_main_area">
        <div class="container">
            <div class="row">
                <div class="col-12">

                    <div class="privacy_content section_2">
                        <h1 class="text-center">PPF TERMS AND CONDITIONS</h1>

                        <p>We as ‘Mafra’ stand confidently behind its detail max products—Neutral Foam Shampoo, Ceramic Shampoo, All-Purpose Cleaner, Ceramic Ultra-Speed Wax, Glass Cleaner & Degreaser, All-Round Plastic Protectant, Foam Gun Prewash, and Paint Protection Film—guaranteeing our quality and free from manufacturing defects. The warranty covers issues like discoloration, cracking, blistering, delamination, excessive colour change or yellowing, and staining, ensuring these are solely attributable to manufacturing processes.</p>

                        <p>This warranty excludes coverage for regular wear and tear, damage from road debris impact, accidents, watermarks, scratches, deliberate damage, and failure to follow aftercare instructions. It also does not cover errors in installation, failure to comply with guidelines, improper storage, application on repainted panels, or non-clear-coated surfaces. The warranty applies solely to non-commercial vehicles and is non-transferable.</p>

                        <p>During the warranty period, the company may, at its discretion and no cost, remove or replace the product if a manufacturing defect causes it to underperform according to the warranty terms.</p>

                        <p>To claim the warranty, contact our customer support at customer.support@manmachineworks.com within 30 days of delivery. To receive service, provide proof of purchase and the warranty card.</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Privacy Policy area end-->


    @include("include/footer")
</body>

</html>