<!doctype html>
<html class="no-js" lang="en">
@include("include/head")

<body>
    @include("include/header")

    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>privacy</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Privacy Policy area start-->
    <div class="privacy_policy_main_area">
        <div class="container">
            <div class="row">
                <div class="col-12">

                    <div class="privacy_content section_2">
                        <h1 class="text-center">PRIVACY POLICY</h1>
                        <p>We don’t like it when someone gives away our personal information and neither do you. That’s why we don’t rent, sell, or share your personal information with anyone.</p>
                        <h2>Collection of personally identifiable information:</h2>

                        <p>Mafra collects the email addresses and contact information of those who choose to receive our email newsletters or complete a merchandise order.</p>

                        <p>The information we collect is used for internal review and is then discarded, used to improve the content of our website, and used to notify consumers about updates to our website.</p>

                        <p>Mafra will not sell your email address to another company, nor will we make our email database available to the public.</p>

                        <p>If you have selected to subscribe to one of our e-mail newsletters you can unsubscribe at any time.</p>

                        <h2>Cookies:</h2>

                        <p>Mafra, like most Web sites, uses a feature of your browser to set a “cookie” on your computer. We cannot tell your name or any personal information about you based solely on the cookie.</p>

                        <p>Unless you specifically tell us your name and other identifying information, we will never know who you are. All the cookie tells us is what functions you perform when you are on the site so that we can keep track of your transaction.</p>

                        <p>A cookie also helps Mafra note particular traffic patterns on the site so that we can improve what we offer.</p>

                        <p>Every browser allows you to reject cookies or to choose which cookies you will accept. Rejecting cookies, however, may sometimes interfere with your ability to use our site’s features and benefits.</p>

                        <h2>Security Precautions:</h2>

                        <p>We will cooperate with law enforcement and judicial authorities, and we may provide personally identifiable information to appropriate government authorities upon receipt of a subpoena or court order or to cooperate with a law enforcement investigation.</p>

                        <p>We will fully cooperate with law enforcement agencies in identifying those who use our services for illegal activities.</p>

                        <p>We also reserve the right to report to law enforcement agencies activities that we in good faith believe to be illegal.</p>

                        <p>This privacy policy is subject to change at the sole discretion of Mafra. We will post the changes in a revised policy statement when we modify it.</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Privacy Policy area end-->


    @include("include/footer")
</body>

</html>