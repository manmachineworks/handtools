<!doctype html>
<html class="no-js" lang="en">
@include('include/head')
<meta name="csrf-token" content="{{ csrf_token() }}">

<body>
    @include('include/header')
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Register</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="login_page_bg">
        <div class="container">
            <div class="customer_login">
                <div class="row">
                    <div class="col-lg-8 col-md-8">
                        <div class="account_form register">
                            <h2>Register</h2>
                            <div id="message" style="color: green;"></div> <!-- For success messages -->
                     
                            <!-- Registration form -->
                            <form action="{{ route('register.submit') }}" method="POST" id="register-form">
                                @csrf

                                <!-- Name -->
                                <p>
                                    <label>Name <span>*</span></label>
                                    <input type="text" name="name" value="{{ old('name') }}" required>
                                    @error('name')
                                <div style="color:red;">{{ $message }}</div>
                                @enderror
                                </p>

                                <!-- Phone Number -->
                                <p>
                                    <label>Phone <span>*</span></label>
                                <div style="color:red;">Please enter your 10-digit phone number, excluding any country code or extension.</div>
                                <input type="text" name="phone" value="{{ old('phone') }}" required>
                                <button id="verify-btn" class="m-2" type="button">Verify Phone</button>
                                @error('phone')
                                <div style="color:red;">{{ $message }}</div>
                                @enderror
                                <div id="verified-phone"></div>
                                </p>

                                <!-- OTP Input -->
                                <div id="otp-input" class="mb-2">
                                    <input type="text" class="mx-2" name="otp" placeholder="Enter OTP" />
                                    <div id="error-message" style="color: red;"></div> <!-- Error message for OTP -->
                                </div>



                                <!-- Email -->
                                <p>
                                    <label>Email address <span>*</span></label>
                                    <input type="email" name="email" value="{{ old('email') }}" required>
                                    @error('email')
                                <div style="color:red;">{{ $message }}</div>
                                @enderror
                                </p>

                                <!-- Password -->
                                <p>
                                    <label>Password <span>*</span></label>
                                    <input type="password" name="password" required>
                                    @error('password')
                                <div style="color:red;">{{ $message }}</div>
                                @enderror
                                </p>

                                <!-- Confirm Password -->
                                <p>
                                    <label>Confirm Password <span>*</span></label>
                                    <input type="password" name="password_confirmation" required>
                                </p>

                                <!-- Register Button -->
                                <div class="login_submit">
                                    <button id="register-btns" type="submit" disabled>Register</button>
                                </div>
                            </form>

                            <!-- Forgot Password Link -->
                            <div class="forgot_password_link">
                                <a href="{{ route('password.request') }}">Forgot Password?</a>
                            </div>

                            @if (session('success'))
                            <div>{{ session('success') }}</div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('include/footer')
    <style>
        button:disabled {
            background-color: #cccccc;
            /* Light grey background for disabled button */
            color: #666666;
            /* Darker text color for disabled state */
            cursor: not-allowed;
            /* Shows a 'not allowed' cursor */
        }
    </style>
    <script>
        $(document).ready(function() {
            $('#otp-input').hide();
            $('#register-btns').prop('disabled', true).addClass('disabled');


            $('#verify-btn').on('click', function() {
                const phoneNumber = $('input[name="phone"]').val();

                if (!phoneNumber) {
                    alert('Please enter a valid phone number.');
                    return;
                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: '{{ route('send-otp') }}',
                    method: 'POST',
                    data: {
                        phone: phoneNumber,
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#otp-input').show();
                            $('#verify-btn').text('Resend OTP');
                            $('#message').text('OTP sent successfully!'); // Success message
                            $('#error-message').text(''); // Clear errors
                        } else {
                            $('#error-message').text(response.message || 'Failed to send OTP.');
                        }
                    },
                    error: function(xhr) {
                        $('#error-message').text('An error occurred while sending OTP.');
                    }
                });
            });

            $('input[name="otp"]').on('input', function() {
                const otp = $(this).val();
                const phoneNumber = $('input[name="phone"]').val();

                if (otp.length === 6) {
                    $.ajax({
                        url: '{{ route('verify-otp') }}',
                        method: 'POST',
                        data: {
                            phone: phoneNumber,
                            otp: otp,
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            if (response.verified) {
                                $('#message').text('Phone number verified successfully!')
                                    .addClass('alert alert-success');
                                $('#otp-input').hide();
                                $('#verify-btn').remove();
                                $('input[name="phone"]').hide();
                                $('input[name="phone"]').after('<input type="hidden" name="phone" value="' + phoneNumber + '">');
                                $('#verified-phone').html('<div class="alert alert-info">Verified Phone Number: ' + phoneNumber + '</div>');
                                $('#register-btns').prop('disabled', false);
                            } else {
                                // Update the error-message div with the error from the response
                                $('#error-message').text(response.message || 'Incorrect OTP.');
                            }
                        },
                        error: function(xhr) {
                            // If there’s an error, display the error message
                            const response = xhr.responseJSON;
                            if (response && response.message) {
                                $('#error-message').text(response.message); // Error message from the server
                            } else {
                                $('#error-message').text('An error occurred during verification.');
                            }
                        }
                    });
                }
            });

        });
    </script>



</body>

</html>