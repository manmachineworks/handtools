<!doctype html>
<html class="no-js" lang="en">


@include("include/head")


<body>

    @include("include/header")


    <div class="faq_page_bg">
        <div class="container">
            <!--faq area start-->
            <div class="faq_content_area">
                <div class="row">
                    <div class="col-12">
                        <div class="faq_content_wrapper">
                            <h4>Below are frequently asked questions, you may find the answer for yourself</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id erat sagittis, faucibus metus malesuada, eleifend turpis. Mauris semper augue id nisl aliquet, a porta lectus mattis. Nulla at tortor augue. In eget enim diam. Donec gravida tortor sem, ac fermentum nibh rutrum sit amet. Nulla convallis mauris vitae congue consequat. Donec interdum nunc purus, vitae vulputate arcu fringilla quis. Vivamus iaculis euismod dui.</p>

                        </div>
                    </div>
                </div>
            </div>
            <!--faq area end-->

            <!--Accordion area-->
           <div class="accordion_area">
    <div class="row">
        <div class="col-6">
            <div id="accordion1" class="card__accordion">
                <div class="card card_dipult">
                    <div class="card-header card_accor" id="heading1">
                        <button class="btn btn-link" data-bs-toggle="collapse" data-bs-target="#collapse1" aria-expanded="true" aria-controls="collapse1">
                            EXTERIOR CLEANING
                            <i class="fa fa-plus"></i>
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                    <div id="collapse1" class="collapse show" aria-labelledby="heading1" data-bs-parent="#accordion1">
                        <div class="card-body">
                            <ul>
                                <li><a href="{{ route('products.subcategory', Str::slug('All Purpose Cleaner')) }}">All Purpose Cleaner</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Shampoos')) }}">Shampoos</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Snow Foam Shampoo')) }}">Snow Foam Shampoo</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Bug & Tar Remover')) }}">Bug & Tar Remover</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Pre Wash')) }}">Pre Wash</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Car Clay')) }}">Car Clay</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Iron Remover')) }}">Iron Remover</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Traffic Film Remover')) }}">Traffic Film Remover</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card card_dipult">
                    <div class="card-header card_accor" id="heading2">
                        <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2">
                            INTERIOR CLEANING
                            <i class="fa fa-plus"></i>
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                    <div id="collapse2" class="collapse" aria-labelledby="heading2" data-bs-parent="#accordion1">
                        <div class="card-body">
                            <ul>
                                <li><a href="{{ route('products.subcategory', Str::slug('Fabric Cleaners')) }}">Fabric Cleaners</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Fabric Protection')) }}">Fabric Protection</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Leather Cleaners')) }}">Leather Cleaners</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Leather Protection')) }}">Leather Protection</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Odour Elimination')) }}">Odour Elimination</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Shampoos')) }}">Shampoos</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Stain Removers')) }}">Stain Removers</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card card_dipult">
                    <div class="card-header card_accor" id="heading3">
                        <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapse3" aria-expanded="false" aria-controls="collapse3">
                            PAINT CORRECTION
                            <i class="fa fa-plus"></i>
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                    <div id="collapse3" class="collapse" aria-labelledby="heading3" data-bs-parent="#accordion1">
                        <div class="card-body">
                            <ul>
                                <li><a href="{{ route('products.subcategory', Str::slug('Polishers & Kits')) }}">Polishers & Kits</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Compounds & Polishes')) }}">Compounds & Polishes</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Foam / Wool Pads')) }}">Foam / Wool Pads</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Sanding Tools')) }}">Sanding Tools</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Backing Plates')) }}">Backing Plates</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Metal & Chrome')) }}">Metal & Chrome</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Masking Tapes')) }}">Masking Tapes</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Digital Gauge')) }}">Digital Gauge</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div id="accordion2" class="card__accordion">
                <div class="card card_dipult">
                    <div class="card-header card_accor" id="heading4">
                        <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapse4" aria-expanded="false" aria-controls="collapse4">
                            WAXES & SEALANTS
                            <i class="fa fa-plus"></i>
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                    <div id="collapse4" class="collapse" aria-labelledby="heading4" data-bs-parent="#accordion2">
                        <div class="card-body">
                            <ul>
                                <li><a href="{{ route('products.subcategory', Str::slug('Graphene Coating')) }}">Graphene Coating</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Ceramic Coating')) }}">Ceramic Coating</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Hybrid Waxes')) }}">Hybrid Waxes</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Spray Waxes')) }}">Spray Waxes</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Liquid Waxes')) }}">Liquid Waxes</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Paste Waxes')) }}">Paste Waxes</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card card_dipult">
                    <div class="card-header card_accor" id="heading5">
                        <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapse5" aria-expanded="false" aria-controls="collapse5">
                            MACHINES & TOOLS
                            <i class="fa fa-plus"></i>
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                    <div id="collapse5" class="collapse" aria-labelledby="heading5" data-bs-parent="#accordion2">
                        <div class="card-body">
                            <ul>
                                <li><a href="{{ route('products.subcategory', Str::slug('Paint Correction')) }}">Paint Correction</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Car Vacuum')) }}">Car Vacuum</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Steamers')) }}">Steamers</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Air Blowers')) }}">Air Blowers</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Paint Cleaners')) }}">Paint Cleaners</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Paint Sprays')) }}">Paint Sprays</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Tool Box')) }}">Tool Box</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card card_dipult">
                    <div class="card-header card_accor" id="heading6">
                        <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapse6" aria-expanded="false" aria-controls="collapse6">
                            PPF FILMS
                            <i class="fa fa-plus"></i>
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                    <div id="collapse6" class="collapse" aria-labelledby="heading6" data-bs-parent="#accordion2">
                        <div class="card-body">
                            <ul>
                                <li><a href="{{ route('products.subcategory', Str::slug('Car Films')) }}">Car Films</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Heat Gun')) }}">Heat Gun</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Scrapper')) }}">Scrapper</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Nano Coating')) }}">Nano Coating</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card card_dipult">
                    <div class="card-header card_accor" id="heading7">
                        <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapse7" aria-expanded="false" aria-controls="collapse7">
                            INTERIOR CLEANING
                            <i class="fa fa-plus"></i>
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                    <div id="collapse7" class="collapse" aria-labelledby="heading7" data-bs-parent="#accordion2">
                        <div class="card-body">
                            <ul>
                                <li><a href="{{ route('products.subcategory', Str::slug('Fabric Cleaners')) }}">Fabric Cleaners</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Fabric Protection')) }}">Fabric Protection</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Leather Cleaners')) }}">Leather Cleaners</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Leather Protection')) }}">Leather Protection</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Odour Elimination')) }}">Odour Elimination</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Shampoos')) }}">Shampoos</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Stain Removers')) }}">Stain Removers</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card card_dipult">
                    <div class="card-header card_accor" id="heading8">
                        <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapse8" aria-expanded="false" aria-controls="collapse8">
                            WHEELS & TIRES
                            <i class="fa fa-plus"></i>
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                    <div id="collapse8" class="collapse" aria-labelledby="heading8" data-bs-parent="#accordion2">
                        <div class="card-body">
                            <ul>
                                <li><a href="{{ route('products.subcategory', Str::slug('Rim Cleaners')) }}">Rim Cleaners</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Tire Cleaners')) }}">Tire Cleaners</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Tire Dressings')) }}">Tire Dressings</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Iron Removers')) }}">Iron Removers</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Wheel Brushes')) }}">Wheel Brushes</a></li>
                                <li><a href="{{ route('products.subcategory', Str::slug('Tire Cleaners')) }}">Tire Cleaners</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

            <!--Accordion area end-->
        </div>
    </div>



    @include("include/footer")

</body>

</html>