<!doctype html>
<html class="no-js" lang="en">
@include("include/head")

<body>
    @include("include/header")

    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Refund</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Privacy Policy area start-->
    <div class="privacy_policy_main_area">
        <div class="container">
            <div class="row">
                <div class="col-12">

                    <div class="privacy_content section_2">
                        <h1 class="text-center">REFUND AND RETURNS POLICY</h1>

                        <p>Mafra gladly accepts returns on all new merchandise.</p>

                        <p>Note: All returns are subject to a 15% restocking fee. Please try to include all original packaging, manuals, and ancillary materials to avoid being penalized.</p>

                        <h2>Return and Refund:</h2>

                        <p>In the rare event that you are not fully satisfied with what you ordered, just return it to us in the original packaging and we will refund you, subject to 15% restocking fees.</p>

                        <p>After 3 days of the Delivery date, we will not accept any refunds or returns.</p>

                        <p>Refunds will be given on items only and exclude shipping costs or any other charges. All items must be returned in the original package, cannot be damaged or installed, and must be in original condition.</p>

                        <p>Certain items are not returnable, all Liquid products, Polishers, Products on sale/discount & some plastic products.</p>

                        <p>For COD orders, we offer return/exchange but the amount is refunded in the Mafra wallet which you can use in your future orders.</p>

                        <p>Customer returns for items received as part of a “free shipping” offer will be credited for the amount of the returned items less actual outbound shipping charges paid by us and any restocking fee that may apply.</p>

                        <p>The final amount will be refunded within 3-5 business days of receiving the returned product.</p>

                        <p>For all returns, please call +91 - 82-52-300-400 between 12.00-3.00 pm or email us at customer.support@manmachineworks.com. Provide a specific reason for your return.</p>

                        <h2>Replacement:</h2>

                        <p>If you have received an item in a ‘Damaged’ or ‘Defective’ condition or it is ‘Not as Described’, you may request a replacement at no extra cost, or in case we can’t replace the product we will give you a full refund.</p>

                        <p>When packaging your items for shipping, include a copy of the original invoice in the package.</p>

                        <p>We strongly recommend packing any items with fragile components with sufficient padding. Note that we are not responsible for products being returned to us that are damaged mid-shipment.</p>

                        <p>For all returns, please call +91 - 82-52-300-400 between 10:00-18:30 or email: customer.support@manmachineworks.com. Provide a specific reason for your replacement.</p>

                        <h2>Cancellation Policy:</h2>

                        <p>You may cancel your order at any time before shipment of the order, within 24 hours of the time your order was placed. Orders cancelled 24 hours before shipment are subject to a 15% restocking fee, which will be subtracted from the credit amount issued to your credit card. To cancel orders please call +91 - 82-52-300-400 between 10:00-18:30 or email: customer.support@manmachineworks.com.</p>

                        <h2>Pricing Policy:</h2>

                        <p>The Price displayed for products on our website represents the full retail price listed on the product itself as shared by Manufacturers or Distributors.</p>

                        <p>While we attempt to ensure that this information is accurate, there may be cases where the price of the product delivered is different from the price given on the website due to various reasons including time lag in updating prices post changes in price, the different prices being used by manufacturers in different regions</p>

                        <p>In this case, we will only charge you the price you place the order.</p>

                        <h2>Contact Us:</h2>
                        <p>If you wish to contact us with any further questions, comments, or concerns, please call +91 - 82-52-300-400 between 10:00 and 18:30 or email: customer.support@manmachineworks.com</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Privacy Policy area end-->


    @include("include/footer")
</body>

</html>