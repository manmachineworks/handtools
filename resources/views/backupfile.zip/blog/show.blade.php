<!doctype html>
<html class="no-js" lang="en">


@include("include/head")


<body>

    @include("include/header")

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Blog</li>
                            <li>{{ $blog->blog_title }} </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="blog_bg_area blog_details_bg">
        <div class="container">
            <div class="blog_page_section">
                <div class="row">
                    <div class="col-lg-9 col-md-12">
                        <!--blog grid area start-->
                        <div class="blog_wrapper blog_details">
                            <article class="single_blog">
                                <figure>
                                    <div class="post_header">
                                        <h3 class="post_title"> {{ $blog->blog_title }}</h3>
                                        <div class="blog_meta">
                                            <span class="author">Posted by : <a href="#">admin</a> / </span>
                                            <span class="meta_date">On : {{ $blog->created_at->format('d-m-y') }}</span>
                                            <!-- <span class="post_category">In : <a href="#">Company, Image, Travel</a></span> -->
                                        </div>
                                    </div>
                                    <div class="blog_thumb">
                                        <img src="/{{ $blog->blog_image }}" alt="">
                                    </div>
                                    <figcaption class="blog_content">
                                        <div class="post_content">
                                            {!! $blog->blog_detail !!}
                                        </div>
                                        <!-- <div class="entry_content">
                                            <div class="post_meta">
                                                <span>Tags: </span>
                                                <span><a href="#">, fashion</a></span>
                                                <span><a href="#">, t-shirt</a></span>
                                                <span><a href="#">, white</a></span>
                                            </div>

                                            <div class="social_sharing">
                                                <p>share this post:</p>
                                                <ul>
                                                    <li><a href="#" title="facebook"><i class="fa fa-facebook"></i></a></li>
                                                    <li><a href="#" title="twitter"><i class="fa fa-twitter"></i></a></li>
                                                    <li><a href="#" title="pinterest"><i class="fa fa-pinterest"></i></a></li>
                                                    <li><a href="#" title="google+"><i class="fa fa-google-plus"></i></a></li>
                                                    <li><a href="#" title="linkedin"><i class="fa fa-linkedin"></i></a></li>
                                                </ul>
                                            </div>
                                        </div> -->
                                    </figcaption>
                                </figure>
                            </article>
                            <!-- <div class="related_posts">
                                <h3>Related posts</h3>
                                <div class="row">
                                    <div class="col-lg-4 col-md-6">
                                        <article class="single_related">
                                            <figure>
                                                <div class="related_thumb">
                                                    <img src="assets/img/blog/blog7.jpg" alt="">
                                                </div>
                                                <figcaption class="related_content">
                                                    <h4><a href="#">Post with Gallery</a></h4>
                                                    <div class="blog_meta">
                                                        <span class="author">By : <a href="#">admin</a> / </span>
                                                        <span class="meta_date"> July 05, 2022 </span>
                                                    </div>
                                                </figcaption>
                                            </figure>
                                        </article>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <article class="single_related">
                                            <figure>
                                                <div class="related_thumb">
                                                    <img src="assets/img/blog/blog8.jpg" alt="">
                                                </div>
                                                <figcaption class="related_content">
                                                    <h4><a href="#">Post with Audio</a></h4>
                                                    <div class="blog_meta">
                                                        <span class="author">By : <a href="#">admin</a> / </span>
                                                        <span class="meta_date"> July 05, 2022 </span>
                                                    </div>
                                                </figcaption>
                                            </figure>
                                        </article>
                                    </div>
                                    <div class="col-lg-4 col-md-6">
                                        <article class="single_related">
                                            <figure>
                                                <div class="related_thumb">
                                                    <img src="assets/img/blog/blog9.jpg" alt="">
                                                </div>
                                                <figcaption class="related_content">
                                                    <h4><a href="#">Maecenas ultricies</a></h4>
                                                    <div class="blog_meta">
                                                        <span class="author">By : <a href="#">admin</a> / </span>
                                                        <span class="meta_date"> July 05, 2022 </span>
                                                    </div>
                                                </figcaption>
                                            </figure>
                                        </article>
                                    </div>
                                </div>
                            </div> -->



                        </div>
                        <!--blog grid area start-->
                    </div>
                    <div class="col-lg-3 col-md-12">
                        <div class="blog_sidebar_widget">


                            <div class="widget_list widget_post">
                                <div class="widget_title">
                                    <h3>Recent Posts</h3>
                                </div>
                                @foreach($recents as $recent)
                                <div class="post_wrapper">
                                    <div class="post_thumb">
                                        <a href="{{ route('blog_show', $recent->url ) }}"><img src="/{{$recent->blog_image}}" alt=""></a>
                                    </div>
                                    <div class="post_info">
                                        <h4><a href="{{ route('blog_show', $recent->url ) }}">{{$recent->blog_title}}</a></h4>
                                        <span>{{ $recent->created_at }} </span>
                                    </div>
                                </div>
                                @endforeach

                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include("include/footer")

</body>

</html>