<!doctype html>
<html class="no-js" lang="en">


@include("include/head")


<body>

    @include("include/header")

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Blog</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="blog_bg_area">
        <div class="container">
            <!--blog area start-->
            <div class="blog_page_section">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="blog_wrapper mb-30">
                            <div class="blog_header">
                                <h1>Blog</h1>
                            </div>
                            <div class="blog_wrapper_inner">
                                @foreach ($blogs as $blog)
                                <article class="single_blog">
                                    <figure>
                                        <div class="blog_thumb">
                                            <a href="/"><img src="/{{ $blog->blog_image}}" class="h-100" alt=""></a>
                                        </div>
                                        <figcaption class="blog_content">
                                            <h4 class="post_title"><a href="{{ route('blog_show',$blog->url )}}">{{ $blog->blog_title }}</a></h4>
                                            <div class="blog_meta">
                                                <span class="author">Posted by : <a href="#">admin</a> / </span>
                                                <span class="meta_date">Posted on : <a href="#">{{ $blog->created_at->format('d-m-y') }}</a></span>
                                            </div>
                                            <div class="blog_desc">
                                                <p>
                                                    {!! Str::limit($blog->blog_detail, 400) !!}
                                                </p>
                                            </div>
                                            <footer class="btn_more">
                                                <a href="{{ route('blog_show', $blog->url) }}"> Read more</a>
                                            </footer>
                                        </figcaption>
                                    </figure>
                                </article>
                                @endforeach
                            </div>
                        </div>
                        <!--blog pagination area start-->
                        {{ $blogs->links() }}
                        <!--blog pagination area end-->
                    </div>
                    <!-- <div class="col-lg-3 col-md-12">
                        <div class="blog_sidebar_widget">
                            <div class="widget_list widget_search">
                                <div class="widget_title">
                                    <h3>Search</h3>
                                </div>
                                <form action="#">
                                    <input placeholder="Search..." type="text">
                                    <button type="submit">search</button>
                                </form>
                            </div>
                            <div class="widget_list comments">
                                <div class="widget_title">
                                    <h3>Recent Comments</h3>
                                </div>
                                <div class="post_wrapper">
                                    <div class="post_thumb">
                                        <a href="blog-details.html"><img src="assets/img/blog/comment2.png.jpg" alt=""></a>
                                    </div>
                                    <div class="post_info">
                                        <span> <a href="#">demo</a> says:</span>
                                        <a href="blog-details.html">Quisque semper nunc</a>
                                    </div>
                                </div>
                                <div class="post_wrapper">
                                    <div class="post_thumb">
                                        <a href="blog-details.html"><img src="assets/img/blog/comment2.png.jpg" alt=""></a>
                                    </div>
                                    <div class="post_info">
                                        <span><a href="#">admin</a> says:</span>
                                        <a href="blog-details.html">Quisque orci porta...</a>
                                    </div>
                                </div>
                                <div class="post_wrapper">
                                    <div class="post_thumb">
                                        <a href="blog-details.html"><img src="assets/img/blog/comment2.png.jpg" alt=""></a>
                                    </div>
                                    <div class="post_info">
                                        <span><a href="#">demo</a> says:</span>
                                        <a href="blog-details.html">Quisque semper nunc</a>
                                    </div>
                                </div>
                                <div class="post_wrapper">
                                    <div class="post_thumb">
                                        <a href="blog-details.html"><img src="assets/img/blog/comment2.png.jpg" alt=""></a>
                                    </div>
                                    <div class="post_info">
                                        <span><a href="#">admin</a> says:</span>
                                        <a href="blog-details.html">Quisque semper nunc</a>
                                    </div>
                                </div>
                            </div>
                            <div class="widget_list widget_post">
                                <div class="widget_title">
                                    <h3>Recent Posts</h3>
                                </div>
                                <div class="post_wrapper">
                                    <div class="post_thumb">
                                        <a href="blog-details.html"><img src="assets/img/blog/blog6.jpg" alt=""></a>
                                    </div>
                                    <div class="post_info">
                                        <h4><a href="blog-details.html">Blog image post</a></h4>
                                        <span>July 05, 2022 </span>
                                    </div>
                                </div>
                                <div class="post_wrapper">
                                    <div class="post_thumb">
                                        <a href="blog-details.html"><img src="assets/img/blog/blog7.jpg" alt=""></a>
                                    </div>
                                    <div class="post_info">
                                        <h4><a href="blog-details.html">Post with Gallery</a></h4>
                                        <span>July 05, 2022 </span>
                                    </div>
                                </div>
                                <div class="post_wrapper">
                                    <div class="post_thumb">
                                        <a href="blog-details.html"><img src="assets/img/blog/blog8.jpg" alt=""></a>
                                    </div>
                                    <div class="post_info">
                                        <h4><a href="blog-details.html">Post with Audio</a></h4>
                                        <span>July 05, 2022 </span>
                                    </div>
                                </div>
                                <div class="post_wrapper">
                                    <div class="post_thumb">
                                        <a href="blog-details.html"><img src="assets/img/blog/blog9.jpg" alt=""></a>
                                    </div>
                                    <div class="post_info">
                                        <h4><a href="blog-details.html">Post with Video</a></h4>
                                        <span>July 05, 2022 </span>
                                    </div>
                                </div>
                            </div>
                            <div class="widget_list widget_categories">
                                <div class="widget_title">
                                    <h3>Categories</h3>
                                </div>
                                <ul>
                                    <li><a href="#">Audio</a></li>
                                    <li><a href="#">Company</a></li>
                                    <li><a href="#">Gallery</a></li>
                                    <li><a href="#">Image</a></li>
                                    <li><a href="#">Other</a></li>
                                    <li><a href="#">Travel</a></li>
                                </ul>
                            </div>
                            <div class="widget_list widget_tag">
                                <div class="widget_title">
                                    <h3>Tag products</h3>
                                </div>
                                <div class="tag_widget">
                                    <ul>
                                        <li><a href="#">asian</a></li>
                                        <li><a href="#">brown</a></li>
                                        <li><a href="#">euro</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
            <!--blog area end-->


        </div>
    </div>

    @include("include/footer")

</body>

</html>