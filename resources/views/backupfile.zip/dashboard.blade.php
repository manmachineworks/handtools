<!doctype html>
<html class="no-js" lang="en">
@include("include/head")

<body>
    @include("include/header")

    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Dashboard</li>

                            <!-- my account start  -->
                            <div class="account_page_bg">
                                <div class="container">
                                    <section class="main_content_area">
                                        <div class="account_dashboard">
                                            <div class="row">
                                                <div class="col-sm-12 col-md-3 col-lg-3">
                                                    <!-- Nav tabs -->
                                                    <div class="dashboard_tab_button">
                                                        <ul role="tablist" class="nav flex-column dashboard-list">
                                                            <li><a href="#dashboard" data-bs-toggle="tab" class="nav-link active">Dashboard</a></li>
                                                            <li> <a href="#orders" data-bs-toggle="tab" class="nav-link">Orders</a></li>
                                                            <!-- <li><a href="#downloads" data-bs-toggle="tab" class="nav-link">Reset Password</a></li> -->
                                                            <li><a href="#address" data-bs-toggle="tab" class="nav-link">Addresses</a></li>
                                                            <li><a href="#account-details" data-bs-toggle="tab" class="nav-link">Account details</a></li>
                                                            <li>
                                                                <form action="{{ route('logout') }}" method="POST">
                                                                    @csrf
                                                                    <button type="submit" class="nav-link btn btn-link">Logout</button>
                                                                </form>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-9 col-lg-9">
                                                    <!-- Tab panes -->
                                                    <div class="tab-content dashboard_content">
                                                        <div class="tab-pane fade show active" id="dashboard">
                                                            <h3>Dashboard -></h3>
                                                            <h3>Orders</h3>
                                                            <div class="table-responsive">
                                                                <table class="table">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Order</th>
                                                                            <th>Date</th>
                                                                            <th>Status</th>
                                                                            <th>Total</th>
                                                                            <th>Actions</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        @php $i = 1; @endphp
                                                                        @foreach($ordersGroupedByTransaction as $transactionId => $orders)
                                                                        @foreach($orders as $order)
                                                                        <tr>
                                                                            <td>{{ $i }}</td>
                                                                            <td>{{ $order->created_at }}</td>
                                                                            <td><span class="{{ $order->status == 'success' ? 'success' : 'failure' }}">{{ $order->status }}</span></td>
                                                                            <td>{{ $order->amount }} for {{ $orders->count() }} item{{ $orders->count() > 1 ? 's' : '' }}</td>
                                                                            <td>
                                                                                <a href="{{ route('orders.view', $order->id) }}" class="view"><button class="btn btn-danger btn-sm">View</button></a>
                                                                                @if($order->order_status == 'active')
                                                                                <form action="{{ route('orders.cancel', $order->id) }}" method="POST" style="display:inline;">
                                                                                    @csrf
                                                                                    <button type="submit" class="btn btn-danger btn-sm">Cancel</button>
                                                                                </form>
                                                                                @else
                                                                                <button class="btn btn-danger btn-sm bg-danger">Canceled</button>
                                                                                @endif
                                                                            </td>
                                                                        </tr>
                                                                        @php $i++; @endphp
                                                                        @endforeach
                                                                        @endforeach
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="orders">
                                                            <h3>Orders</h3>
                                                            <div class="table-responsive">
                                                                <table class="table">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>Order</th>
                                                                            <th>Date</th>
                                                                            <th>Status</th>
                                                                            <th>Total</th>
                                                                            <th>Actions</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        @php $i = 1; @endphp
                                                                        @foreach($ordersGroupedByTransaction as $transactionId => $orders)
                                                                        @foreach($orders as $order)
                                                                        <tr>
                                                                            <td>{{ $i }}</td>
                                                                            <td>{{ $order->created_at }}</td>
                                                                            <td><span class="{{ $order->status == 'success' ? 'success' : 'failure' }}">{{ $order->status }}</span></td>
                                                                            <td>{{ $order->amount }} for {{ $orders->count() }} item{{ $orders->count() > 1 ? 's' : '' }}</td>
                                                                            <td>
                                                                                <a href="{{ route('orders.view', $order->id) }}" class="view"><button class="btn btn-danger btn-sm">View</button></a>
                                                                                @if($order->order_status == 'active')
                                                                                <form action="{{ route('orders.cancel', $order->id) }}" method="POST" style="display:inline;">
                                                                                    @csrf
                                                                                    <button type="submit" class="btn btn-danger btn-sm">Cancel</button>
                                                                                </form>
                                                                                @else
                                                                                <button class="btn btn-danger btn-sm bg-danger">Canceled</button>
                                                                                @endif
                                                                            </td>
                                                                        </tr>
                                                                        @php $i++; @endphp
                                                                        @endforeach
                                                                        @endforeach
                                                                    </tbody>
                                                                </table>
                                                            </div>

                                                        </div>
                                                        <!-- <div class="tab-pane fade" id="downloads">
                                                            <h3>Reset Password</h3>
                                                            <div class="login">
                                                                <div class="login_form_container">
                                                                    <div class="account_login_form">
                                                                        <form action="#">

                                                                            <label>Password</label>
                                                                            <input type="password" name="password">
                                                                            <label>ConfirmPassword</label>
                                                                            <input type="cpassword" name="cpassword">

                                                                            <div class="save_button primary_btn default_button">
                                                                                <button type="submit">Save</button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div> -->

                                                        <div class="tab-pane" id="address">
                                                            <a href="{{ route('add_address.form')}}" class="btn btn-danger">Add Address</a>
                                                            <p>The following addresses will be used on the checkout page by default.</p>
                                                            <h4 class="billing-address">Billing address</h4>
                                                            <!-- <a href="#" class="view">Edit</a> -->
                                                            @foreach($addresses as $address)
                                                            <form method="get" action="{{ route('address.edit.form', $address->id) }}">
                                                                @csrf
                                                                <p><strong>{{ $address->city }}</strong></p>
                                                                <address>
                                                                    <span><strong>City:</strong> {{ $address->city }}</span>,
                                                                    <br>
                                                                    <span><strong>Address:</strong> {{ $address->address }}</span>,
                                                                    <br>
                                                                    <span><strong>ZIP:</strong> {{ $address->pin_code }}</span>,
                                                                    <br>
                                                                    <span><strong>Country:</strong> {{ $address->country }}</span>
                                                                    <button class="" type="submit">Edit</button>
                                                                </address>
                                                            </form>
                                                            @endforeach
                                                        </div>


                                                        <div class="tab-pane fade" id="account-details">
                                                            <h3>Account details </h3>
                                                            <p><b>Name : </b> {{$user->name}}</p>
                                                            <p><b>Mail : </b> {{$user->email}}</p>
                                                            <p><b>Phone : </b> {{$user->phone}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                            </div>
                            <!-- my account end   -->

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


    @include("include/footer")
</body>

</html>