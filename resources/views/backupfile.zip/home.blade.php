<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from htmldemo.net/mazlay/mazlay/coming-soon.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2024 07:29:06 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Mafra - Under Maintaince</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

    <!-- CSS 
    ========================= -->


    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <!--coming soon area start-->
    <div class="coming_soon_area js-ripples">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="coming_soon_container">
                        <div class="coming_soon_logo text-center">
                            <h1 class="text-white">Mafra India</h1>
                        </div>

                        <div class="coming_soon_title">
                            <h2>Under Maintaince
                              
                            </h2>
                            <h2>
                                For any query Contact us at <a href="tel:+918252300400">+91 82-52-300-400</a>
                            </h2>
                        </div>
                        <div class="coming_soon_timing">
                            <div data-countdown="2024/09/21"></div>
                        </div>

                        <div class="coming_soon_newsletter">
                            <h3>Subscribe for our next update</h3>
                            <div class="subscribe_form">
                                <form id="mc-form" class="mc-form footer-newsletter">
                                    <input id="mc-email" type="email" autocomplete="off" placeholder="Enter your e-mial..." />
                                    <button id="mc-submit">Subscribe</button>
                                </form>
                                <!-- mailchimp-alerts Start -->
                                <div class="mailchimp-alerts text-centre">
                                    <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                    <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                                    <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                                </div><!-- mailchimp-alerts end -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--coming soon area end-->


    <!-- JS
============================================ -->

    <!-- Plugins JS -->
    <script src="assets/js/plugins.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>



</body>


<!-- Mirrored from htmldemo.net/mazlay/mazlay/coming-soon.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Jul 2024 07:29:06 GMT -->

</html>