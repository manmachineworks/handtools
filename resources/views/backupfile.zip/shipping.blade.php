<!doctype html>
<html class="no-js" lang="en">
@include("include/head")

<body>
    @include("include/header")

    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Shipping</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Privacy Policy area start-->
    <div class="privacy_policy_main_area">
        <div class="container">
            <div class="row">
                <div class="col-12">

                    <div class="privacy_content section_2">
                        <h1 class="text-center">Shipping</h1>
                        <h2>What Does Shipping Include?</h2>

                        <p>All orders placed at Mafra are dispatched via reputed couriers. Currently, we are shipping through Delhivery, Express, DTDC & many more.</p>

                        <p>All the orders are shipped within 24-48 hours. Please note that all orders are subject to stock availability, and orders are typically shipped within 1 – 2 working days and take an additional 4-7 working days of shipment time. For some destinations in NORTHEAST, the shipment time may be longer (up to 15 days).</p>

                        <p>During the sale or festival period, some orders may take a longer time for delivery as well.</p>

                        <p>Currently, we are serving in India only.</p>

                        <p>We will notify you when your order is shipped. You will receive a mail within 24 to 48 hours which will include:</p>

                        <ul>
                            <li>Shipping Partner</li>
                            <li>Your Address and Contact Details</li>
                            <li>No. Of Boxes</li>
                            <li>Tracking Id</li>
                            <li>Tracking Link</li>
                        </ul>

                        <p>In the unusual event that any item you have ordered is physically not available, or not in a condition to be shipped to you, we shall inform you accordingly, and cancel the item(s) from your order. In such cases, your credit card will not be charged.</p>

                        <p>Please note that if you receive less no. of the box, or your order is tampered with, damaged, or missing, please do mention it on POD, click the photo, and call us to resolve this issue at +91 - 82-52-300-400 between 10:00-18:30 or email us at customer.support@manmachineworks.com</p>

                        <h2>How Can I Track My Product Shipment?</h2>

                        <p>Orders once processed and shipped can be tracked using the consignment/tracking number. A mail is sent to the customer after the order is shipped with the tracking number.</p>

                        <p>To track the order, go to the website of the service provider mentioned in your mail or you can check your order status by logging in to our website and clicking on Track your Order.</p>

                        <p>On the “Track Status” Panel enter the tracking number as mentioned in your shipment mail to view your order status or call us at +91 - 82-52-300-400 between 10:00-18:30 or email us at customer.support@manmachineworks.com</p>

                        <h2>Partial Orders:</h2>

                        <p>If an item goes on partial order (if you order 2 products and we only have 1 in stock) we will initiate you to explain the situation before shipping the product.</p>

                        <p>We may ship you the part of your order that is in stock after consenting and when the item becomes available. We will ship you the rest of your order.</p>

                        <p>You will not be charged any additional shipping and handling charges for the second shipment. We also provide you the option either to cancel the order of the item which is not in stock OR you can buy another product in place of your previously ordered item (which is not in stock).</p>

                        <p>In case the Buyer chooses to cancel items which are not in stock, then we will refund you back the relevant amount of Rupees to your credit card account within 7 business days.</p>

                        <h2>Free Shipping:</h2>

                        <p>Free shipping is available on orders above Rs.500 only.</p>

                        <h2>Cash on Delivery (COD):</h2>

                        <p>Cash on Delivery (COD) will be available on orders above Rs.999 up to Rs.12000/- and it also depends on the courier partner servicing the Pin Code to accept cash as payment at the time of delivery.</p>

                        <p>Please enter your PIN code on the product page to check if COD is available in your location.</p>

                        <p>NOTE: All liquid products are shipped by Surface due to the restriction imposed by the Bureau of Civil Aviation Security (BCAS) and/or the State’s Regulatory Requirements on the courier service providers.</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Privacy Policy area end-->


    @include("include/footer")
</body>

</html>