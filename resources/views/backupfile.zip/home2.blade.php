<!doctype html>
<html class="no-js" lang="en">

@include("include/head")
<style>
    .product_carousel .product_thumb a img {
        height: 325px !important;
    }

    .product_deals_container .single_product {
        overflow: hidden;
        padding: 50px !important;
    }
</style>

<body>

    @include("include/header")
    <!--slider area start-->
    <section class="slider_section mb-80">
        <div class="slider_area slider_carousel owl-carousel">
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/Banner-1.webp">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content">
                                <h1>Premium Care <span>for Your Ride</span></h1>
                                <p>Exclusive Offer -30% Off This Week</p>
                                <a class="button" href="/">shopping now <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/Banner-2.webp">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content center">
                                <h1>Top-Quality <span>Car Care Solutions</span></h1>
                                <p>Exclusive Offer -30% Off This Week</p>
                                <a class="button" href="/">shopping now <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/Banner-3.webp">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content">
                                <h1>Premium Care <span>for Your Ride</span></h1>
                                <p>Exclusive Offer -20% Off This Week</p>
                                <a class="button" href="/">shopping now <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--slider area end-->

    <div class="product_area product_deals">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title mb-35">
                        <h2><span>Today</span> Hot Deals</h2>
                        <p>Get the best deals on top-notch auto detailing products. High-performance cleaners, protectants, and polishes for a showroom shine at unbeatable prices.</p>
                    </div>
                </div>
            </div>
            <div class="product_deals_container">
                <div class="row">
                    <div class="product_carousel product_column2 owl-carousel">
                        @foreach($todayhotDeals as $product)
                        <div class="col-lg-3">
                            <article class="single_product">
                                <figure>
                                    <div class="product_thumb">
                                        <a class="primary_img" href="{{ route('product.show', $product->url) }}">
                                            @if($product->images->isNotEmpty())
                                            <img src="{{ asset($product->images->first()->image_url) }}" alt="">
                                            @else
                                            <img src="default_image_path.jpg" alt="">
                                            @endif
                                        </a>
                                        <div class="label_product">
                                            @if($product->mrp > $product->sale_price)
                                            @php
                                            $discount = (($product->mrp - $product->sale_price) / $product->mrp) * 100;
                                            @endphp
                                            <span class="label_sale">-{{ round($discount) }}%</span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="product_content">
                                        <p class="manufacture_product"><a href="#"></a></p>
                                        <h4 class="product_name"><a href="{{ url('product/' . $product->url) }}">{{ $product->product_name }}</a></h4>
                                        <div class="product_rating">
                                            <ul>
                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="price_box">
                                            <span class="old_price">Rs {{ $product->mrp }}</span>
                                            <span class="current_price">Rs {{ $product->sale_price }}</span>
                                        </div>
                                        <div class="product_desc">
                                            <p>{!! \Illuminate\Support\Str::limit($product->description, 200) !!}</p>
                                        </div>
                                        <div class="action_links">
                                            <ul>
                                                <li class="add_to_cart"><a href="{{ route('cart.add', $product->id) }}" title="Add to cart">Add to
                                                        cart</a></li>
                                                <li class="wishlist"><a href="{{ route('wishlist.add', $product->id) }}" title="Add to Wishlist"><i class="icon-heart"></i></a></li>
                                            </ul>
                                        </div>

                                    </div>
                                </figure>
                            </article>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mb-80">
        <div class="row">
            <div class="section_title">
                <h2><span>Random</span> Products</h2>
                <p>Essential car detailing products include no-rinse shampoo, color foam, upholstery cleaner shampoo, tyre glaze, and more. These products ensure thorough cleaning and a polished finish.</p>
            </div>

            <div class="product_area">
                <!--banner area end-->
                <div class="row">
                    <div class="product_carousel product_column4 owl-carousel">
                        @foreach($randomProducts as $product)
                        <div class="col-lg-3">
                            <div class="product_items">
                                <article class="single_product">
                                    <figure>
                                        <div class="product_thumb">
                                            <a class="primary_img" href="{{ url('product/' . $product->url) }}">
                                                @if($product->images->isNotEmpty())
                                                <img src="{{ asset($product->images->first()->image_url) }}" alt="">
                                                @else
                                                <img src="default_image_path.jpg" alt="">
                                                @endif
                                            </a>
                                            @if($product->images->count() > 1)
                                            <a class="secondary_img" href="{{ url('product/' . $product->url) }}">
                                                <img src="{{ asset($product->images->get(1)->image_url) }}" alt="" height="200px">
                                            </a>
                                            @endif
                                            <div class="label_product">
                                                @if($product->mrp > $product->sale_price)
                                                @php
                                                $discount = (($product->mrp - $product->sale_price) / $product->mrp) * 100;
                                                @endphp
                                                <span class="label_sale">-{{ round($discount) }}%</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="product_content">
                                            <div class="product_content_inner">

                                                <h4 class="product_name"><a href="{{ url('product/' . $product->url) }}">{{
                                            $product->product_name }}</a></h4>
                                                <div class="product_rating">
                                                    <ul>
                                                        <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                        <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                        <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                        <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                        <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                    </ul>
                                                </div>
                                                <div class="price_box">
                                                    <span class="old_price">Rs {{ $product->mrp }}</span>
                                                    <span class="current_price">Rs {{ $product->sale_price }}</span>
                                                </div>
                                            </div>
                                            <div class="action_links">
                                                <ul>
                                                    <li class="add_to_cart"><a href="{{ route('cart.add', $product->id) }}" title="Add to cart">Add to
                                                            cart</a></li>
                                                    <li class="wishlist"><a href="{{ route('wishlist.add', $product->id) }}" title="Add to Wishlist"><i class="icon-heart"></i></a></li>

                                                </ul>
                                            </div>
                                        </div>
                                    </figure>
                                </article>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--banner area start-->
    <div class="banner_area mb-80">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <figure class="single_banner">
                        <div class="banner_thumb">
                            <a href="/"><img src="assets/img/mafra.jpg" alt=""></a>
                        </div>
                    </figure>
                </div>
                <div class="col-lg-4 col-md-4">
                    <figure class="single_banner">
                        <div class="banner_thumb">
                            <a href="/"><img src="assets/img/maxshine.jpg" alt=""></a>
                        </div>
                    </figure>
                </div>
                <div class="col-lg-4 col-md-4">
                    <figure class="single_banner">
                        <div class="banner_thumb">
                            <a href="/"><img src="assets/img/maniac_line.jpg" alt=""></a>
                        </div>
                    </figure>
                </div>
            </div>
        </div>
    </div>


    <!--home section bg area start-->
    <div class="home_section_bg">
        <!--product area start-->
        <div class="product_area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section_title">
                            <h2><span>our</span> Products</h2>
                            <p>Transform your car with Mafra's superior detailing products, featuring high-performance cleaners, protectants, and polishes that ensure a showroom shine every time. </p>
                        </div>


                        <div class="product_tab_btn">
                            <ul class="nav" role="tablist" id="nav-tab">
                                <li>
                                    <a class="active" data-bs-toggle="tab" href="#Sellers" role="tab" aria-controls="Sellers" aria-selected="true">
                                        Best Sellers
                                    </a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tab" href="#Featured" role="tab" aria-controls="Featured" aria-selected="false">
                                        Featured Products
                                    </a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tab" href="#Arrivals" role="tab" aria-controls="Arrivals" aria-selected="false">
                                        New Arrivals
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>



                <div class="tab-content">
                    <div class="tab-pane fade show active" id="Sellers" role="tabpanel">
                        <div class="row">
                            <div class="product_carousel product_column4 owl-carousel">
                                @foreach($bestSellers as $product)
                                <div class="col-lg-3">
                                    <div class="product_items">
                                        <article class="single_product">
                                            <figure>
                                                <div class="product_thumb">
                                                    <a class="primary_img" href="{{ url('product/' . $product->url) }}">
                                                        @if($product->images->isNotEmpty())
                                                        <img src="{{ asset($product->images->first()->image_url) }}" alt="">
                                                        @else
                                                        <img src="default_image_path.jpg" alt="">
                                                        @endif
                                                    </a>
                                                    @if($product->images->count() > 1)
                                                    <a class="secondary_img" href="{{ url('product/' . $product->url) }}">
                                                        <img src="{{ asset($product->images->get(1)->image_url) }}" alt="" height="200px">
                                                    </a>
                                                    @endif
                                                    <div class="label_product">
                                                        @if($product->mrp > $product->sale_price)
                                                        @php
                                                        $discount = (($product->mrp - $product->sale_price) / $product->mrp) * 100;
                                                        @endphp
                                                        <span class="label_sale">-{{ round($discount) }}%</span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="product_content">
                                                    <div class="product_content_inner">

                                                        <h4 class="product_name"><a href="{{ url('product/' . $product->url) }}">{{
                                            $product->product_name }}</a></h4>
                                                        <div class="product_rating">
                                                            <ul>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="price_box">
                                                            <span class="old_price">Rs {{ $product->mrp }}</span>
                                                            <span class="current_price">Rs {{ $product->sale_price }}</span>
                                                        </div>
                                                    </div>
                                                    <div class="action_links">
                                                        <ul>
                                                            <li class="add_to_cart"><a href="{{ route('cart.add', $product->id) }}" title="Add to cart">Add to
                                                                    cart</a></li>
                                                            <li class="wishlist"><a href="{{ route('wishlist.add', $product->id) }}" title="Add to Wishlist"><i class="icon-heart"></i></a></li>

                                                        </ul>
                                                    </div>
                                                </div>
                                            </figure>
                                        </article>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>

                    <!-- Featured Products Section -->
                    <div class="tab-pane fade" id="Featured" role="tabpanel">
                        <div class="row">
                            <div class="product_carousel product_column4 owl-carousel">
                                @foreach($featuredProducts as $product)
                                <div class="col-lg-3">
                                    <div class="product_items">
                                        <article class="single_product">
                                            <figure>
                                                <div class="product_thumb">
                                                    <a class="primary_img" href="{{ url('product/' . $product->url) }}">
                                                        @if($product->images->isNotEmpty())
                                                        <img src="{{ asset($product->images->first()->image_url) }}" alt="">
                                                        @else
                                                        <img src="default_image_path.jpg" alt="">
                                                        @endif
                                                    </a>
                                                    @if($product->images->count() > 1)
                                                    <a class="secondary_img" href="{{ url('product/' . $product->url) }}">
                                                        <img src="{{ asset($product->images->get(1)->image_url) }}" alt="">
                                                    </a>
                                                    @endif
                                                    <div class="label_product">
                                                        @if($product->mrp > $product->sale_price)
                                                        @php
                                                        $discount = (($product->mrp - $product->sale_price) / $product->mrp) * 100;
                                                        @endphp
                                                        <span class="label_sale">-{{ round($discount) }}%</span>
                                                        @endif
                                                    </div>

                                                </div>
                                                <div class="product_content">
                                                    <div class="product_content_inner">

                                                        <h4 class="product_name"><a href="{{ url('product/' . $product->url) }}">{{
                                            $product->product_name }}</a></h4>
                                                        <div class="product_rating">
                                                            <ul>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="price_box">
                                                            <span class="old_price">Rs {{ $product->mrp }}</span>
                                                            <span class="current_price">Rs {{ $product->sale_price }}</span>
                                                        </div>
                                                    </div>
                                                    <div class="action_links">
                                                        <ul>
                                                            <li class="add_to_cart"><a href="{{ route('cart.add', $product->id) }}" title="Add to cart">Add to cart</a></li>
                                                            <li class="wishlist"><a href="{{ route('wishlist.add', $product->id) }}" title="Add to Wishlist"><i class="icon-heart"></i></a></li>

                                                        </ul>
                                                    </div>
                                                </div>
                                            </figure>
                                        </article>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="Arrivals" role="tabpanel">
                        <div class="row">
                            <div class="product_carousel product_column4 owl-carousel">
                                @foreach($newArrivals as $products)
                                <div class="col-lg-3">
                                    <div class="product_items">
                                        <article class="single_product">
                                            <figure>
                                                <div class="product_thumb">
                                                    <a class="primary_img" href="{{ url('product/' . $products->url) }}">
                                                        @if($products->images->isNotEmpty())
                                                        <img src="{{ asset($products->images->first()->image_url) }}" alt="">
                                                        @else
                                                        <img src="default_image_path.jpg" alt="">
                                                        @endif
                                                    </a>
                                                    @if($products->images->count() > 1)
                                                    <a class="secondary_img" href="{{ url('product/' . $products->url) }}">
                                                        <img src="{{ asset($products->images->get(1)->image_url) }}" alt="">
                                                    </a>
                                                    @endif
                                                    <div class="label_product">
                                                        @if($products->mrp > $products->sale_price)
                                                        @php
                                                        $discount = (($products->mrp - $products->sale_price) / $products->mrp) * 100;
                                                        @endphp
                                                        <span class="label_sale">-{{ round($discount) }}%</span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="product_content">
                                                    <div class="product_content_inner">
                                                        <h4 class="product_name">
                                                            <a href="{{ url('product/' . $products->url) }}">{{ $products->product_name }}</a>
                                                        </h4>
                                                        <div class="product_rating">
                                                            <ul>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                                <li><a href="#"><i class="ion-android-star-outline"></i></a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="price_box">
                                                            <span class="old_price">Rs {{ $products->mrp }}</span>
                                                            <span class="current_price">Rs {{ $products->sale_price }}</span>
                                                        </div>
                                                    </div>
                                                    <div class="action_links">
                                                        <ul>
                                                            <li class="add_to_cart">
                                                                <a href="{{ route('cart.add', $products->id) }}" title="Add to cart">Add to cart</a>
                                                            </li>
                                                            <li class="wishlist">
                                                                <a href="{{ route('wishlist.add', $products->id) }}" title="Add to Wishlist">
                                                                    <i class="icon-heart"></i>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </figure>
                                        </article>
                                    </div>
                                </div>
                                @endforeach
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!--product area end-->

            <!--banner area start-->
            <div class="banner_area mb-80">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <figure class="single_banner">
                                <div class="banner_thumb">
                                    <a href="/category/interior"><img src="assets/img/Interior-exterior-cleaning-banners.webp" alt=""></a>
                                </div>
                            </figure>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <figure class="single_banner">
                                <div class="banner_thumb">
                                    <a href="/category/exterior"><img src="assets/img/Interior-exterior-cleaning-banners-2.webp" alt=""></a>
                                </div>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            <!--banner area end-->
            <div class="blog_bg_area blog_details_bg">
                <div class="container">
                    <div class="blog_page_section">
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <h2 class="text-center">{{ $page->title }}</h2>
                                {!! $page->content !!}</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!--blog area start-->
            <div class="blog_area">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="section_title title_style2">
                                <div class="title_content">
                                    <h2><span>Latest</span> Blog Posts</h2>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="blog_container blog_column4 owl-carousel">
                            @foreach($latestBlogs as $blog)
                            <div class="col-lg-3">
                                <article class="single_blog">
                                    <figure>
                                        <div class="blog_thumb">
                                            <a href="{{ url('blog/' . $blog->urls) }}">
                                                <img src="{{ asset($blog->blog_image) }}" alt="{{ $blog->blog_title }}">
                                            </a>
                                        </div>
                                        <figcaption class="blog_content">
                                            <h4><a href="{{ url('blog/' . $blog->url) }}">{{ $blog->blog_title }}</a></h4>
                                            <div class="post_meta">
                                                <p><a href="#">Ceramic Coating</a> / {{ \Carbon\Carbon::parse($blog->date)->format('d M') }}</p>
                                            </div>
                                            <div class="post_desc">
                                                <p>{!! \Illuminate\Support\Str::limit($blog->blog_detail, 100) !!}</p>
                                            </div>
                                            <footer class="post_readmore">
                                                <a href="{{ url('blog/' . $blog->url) }}">Continue Reading</a>
                                            </footer>
                                        </figcaption>
                                    </figure>
                                </article>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>

            <!--blog area end-->
        </div>
        <!--home section bg area end-->



        @include("include/footer")

</body>

</html>