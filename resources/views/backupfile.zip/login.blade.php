<!doctype html>
<html class="no-js" lang="en">
@include("include/head")

<body>
    @include("include/header")

    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Login</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="login_page_bg">
        <div class="container">
            <div class="customer_login">
                <div class="row">
                    <div class="col-lg-8 col-md-8">
                        <div class="account_form login">
                            <h2>Login</h2>
                            <form action="{{ route('login.submit') }}" method="POST">
                                @error('error')
                                <div class="alert alert-danger">{{ $message }}</div>
                                @enderror
                                @csrf
                                <p>
                                    <label>Email address <span>*</span></label>
                                    <input type="email" name="email" required>
                                    @error('email')
                                <div class="alert alert-danger">{{ $message }}</div>
                                @enderror
                                </p>
                                <p>
                                    <label>Password <span>*</span></label>
                                    <input type="password" name="password" required>
                                    @error('password')
                                <div class="alert alert-danger">{{ $message }}</div>
                                @enderror
                                </p>
                                <div class="login_submit">
                                    <button type="submit">Login</button>
                                </div>
                            </form>

                            <!-- Add a "Forgot Password" link below the registration form -->
                            <div class="forgot_password_link">
                                <a href="{{ route('password.request') }}">Forgot Password?</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include("include/footer")
</body>

</html>