<!doctype html>
<html class="no-js" lang="en">
@include("include/head")

<body>
    @include("include/header")

    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>About Us</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Privacy Policy area start-->
    <div class="privacy_policy_main_area">
        <div class="container">
            <div class="row">
                <div class="col-12">

                    <div class="privacy_content section_2">
                        <h1 class="text-center">ABOUT US</h1>

                        <h2>TEAM Mafra (Mafra India is Owned By Manmachine Works Pvt Ltd)</h2>

                        <p>Mafra is India’s first & largest online site for Car Care Detailing Products. From bringing the best-detailing brands to India to providing training to budding detailers, we are truly your detailing car care products.</p>

                        <p>What we started in 1987 as a dream to serve our customers with professional Car detailing products has unfolded into a remarkable journey of achieving many milestones.</p>


                        <h2>OUR SERVICES</h2>

                        <h2>WHY CHOOSE US</h2>

                        <p>Whatever the reason, our full details will make you want to get in and go for the detailing.</p>

                        <p>We are a one-stop solution to all your Detailing needs. Ceramic Coatings, Paint Protection Films (PPF), Random Orbital Polishers, Rotary Polishers, Compounds & Polishing Pads, Clay Bars, Polishes, Waxes & Sealants, Exterior & Interior Cleaners, Steam Machines, Ozone Purifiers, Vacuum Cleaner, Spray Bottles, Microfiber Towels, Brushes, and many more.</p>

                        <p>You will find everything for your Car Detailing Store.</p>

                        <h2>24/7 CUSTOMER SUPPORT</h2>

                        <p>We seek to provide our clients with the best service to gain their satisfaction. And they’ve shown their trust in our products and services by repeatedly returning to us. Our experienced on-staff experts are here to answer all your inquiries about Orders, Products, Services & Training.</p>

                        <p>For inquiries email: customer.support@manmachineworks.com or call us at +91 - 82-52-300-400</p>

                        <h2>PROFESSIONAL TRAINING AT MAFRA CAR DETAILING</h2>

                        <p>Detailing isn’t an industry that requires having a four-year degree or any specific certification but to be a Successful Detailer, you do need to know all of the proper methods and the Business side of the industry.</p>

                        <p>In India, Mafra Detailing in Noida city is the Certified Car Detailing Training Institute owned by Mr. Anil Sethi, an IDA certified & Skill Verified detailer since 1987, and has been in the Auto Detailing industry for over 38 years, running India’s first, finest, largest, and most successful Detailing ventures and training center in India. If you wish to know more about Professional Detailing and products to get Detailing Training, email us at customer.support@manmachineworks.com or call us at +91 - 82-52-300-400</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Privacy Policy area end-->


    @include("include/footer")
</body>

</html>