<!doctype html>
<html class="no-js" lang="en">


@include("include/head")


<body>

    @include("include/header")

    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Wishlist</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <!--wishlist area start -->
    <div class="wishlist_page_bg">
        <div class="container">
            <div class="wishlist_area">
                <div class="wishlist_inner">
                    <div class="row">
                        <div class="col-12">
                            <div class="table_desc wishlist">
                                <div class="cart_page">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th class="product_remove">Delete</th>
                                                <th class="product_thumb">Image</th>
                                                <th class="product_name">Product</th>
                                                <th class="product-price">Price</th>
                                                <th class="product_quantity">Stock Status</th>
                                                <th class="product_total">Add To Cart</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($wishlist as $item)
                                            <tr>
                                                <td class="product_remove">
                                                    <form action="{{ route('wishlist.delete', $item->id) }}" method="POST" style="display: inline;">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" style="border: none; background: none; color: red;">X</button>
                                                    </form>
                                                </td>
                                                <td class="product_thumb">
                                                    <a href="{{ route('product.show', $item->product->url) }}">
                                                        <img src="{{ asset($item->variant ? $item->variant->variantImages->first()->image_url : $item->product->images->first()->image_url) }}" alt="{{ $item->product->product_name }}">
                                                    </a>
                                                </td>
                                                <td class="product_name"><a href="#">{{ $item->product->product_name }}</a></td>
                                                <td class="product-price">
                                                    {{ $item->variant ? $item->variant->sale_price : $item->product->sale_price }}
                                                </td>
                                                <td class="product_quantity">
                                                    @if ($item->product->stock > 0)
                                                    In Stock
                                                    @else
                                                    Out of Stock
                                                    @endif
                                                </td>
                                                <td class="product_total">
                                                  
                                                   <a href="{{ route('cart.add', $item->product->id) }}" title="Add to cart">Add to cart</a>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <div class="row">
                    <div class="col-12">
                        <div class="wishlist_share">
                            <h4>Share on:</h4>
                            <ul>
                                <li><a href="#"><i class="fa fa-rss"></i></a></li>
                                <li><a href="#"><i class="fa fa-vimeo"></i></a></li>
                                <li><a href="#"><i class="fa fa-tumblr"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </div>


    <!--wishlist area end -->


    <!--shopping cart area end -->

    @include("include/footer")

</body>

</html>