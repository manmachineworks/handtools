 <!--header area start-->

 <!--offcanvas menu area start-->
 <div class="off_canvars_overlay">

 </div>
 <div class="offcanvas_menu">
     <div class="container">
         <div class="row">
             <div class="col-12">
                 <div class="canvas_open">
                     <a href="javascript:void(0)"><i class="ion-navicon"></i></a>
                 </div>
                 <div class="offcanvas_menu_wrapper">
                     <div class="canvas_close">
                         <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
                     </div>
                     <div class="call_support">
                         <p><i class="icon-phone-call" aria-hidden="true"></i> <span>Call us: <a href="tel:+918252300400">+91 8252300400</a></span></p>

                     </div>
                     <div class="header_account">
                         <ul>
                             <li class="language"><a href="#"><img src="/assets/img/logo/language.png" alt=""> english <i class="ion-chevron-down"></i></a>
                                 <ul class="dropdown_language">
                                     <li><a href="#">English</a></li>

                                 </ul>
                             </li>
                             <li class="currency"><a href="#">INR <i class="ion-chevron-down"></i></a>
                                 <ul class="dropdown_currency">

                                     <li><a href="#">INR – India Rupee</a></li>
                                 </ul>
                             </li>
                         </ul>
                     </div>

                     <div class="header_top_links">
                         <ul>

                             @if(!Auth::check())
                             <li><a href="/register">Register</a></li>
                             @endif

                             @if(Auth::check())

                             <li class=""><a href="/dashboard">Dashboard</li>
                             <li>
                                 Welcome {{ Auth::user()->name }}
                             </li>
                             <li>
                                 <form action="{{ route('logout') }}" method="POST">
                                     @csrf
                                     <button type="submit" class="nav-link btn btn-link">Logout</button>
                                 </form>
                                 @else
                                 <a href="{{ route('login') }}">Login</a>
                                 @endif
                                 </a>
                             </li>
                             <li><a href="/cart">Shopping Cart</a></li>
                         </ul>
                     </div>
                     <div class="search_container">
                         <form action="{{ route('searchQuery') }}" method="GET">
                             <div class="hover_category">
                                 <select class="select_option" name="category" id="categori1">
                                     <option selected value="all">All Categories</option>
                                     @foreach($categories as $category)
                                     <option value="{{ route('products.category', Str::slug(strtolower($category->name))) }}">{{ strtoupper($category->name) }}</option>

                                     @endforeach
                                 </select>
                             </div>
                             <div class="search_box">
                                 <input placeholder="Search product..." name="searchq" type="text" required>
                                 <button type="submit">Search</button>
                             </div>
                         </form>
                     </div>


                     <div id="menu" class="text-left ">
                         <ul class="offcanvas_main_menu">
                             <li><a class="active" href="/">Home</a></li>
                             @foreach($categories as $category)
                             <li>
                                 <a href="{{ route('products.category', Str::slug(strtolower($category->slug))) }}">{{ strtoupper($category->name) }} </i></a>

                             </li>
                             @endforeach

                             <li class="menu-item-has-children">
                                 <a href="#">Shop By Brand </a>
                                 <ul class="sub-menu">
                                     <li><a href="/mafra">Mafra</a></li>
                                     <li><a href="/maxshine">Maxshine</a></li>

                                 </ul>
                             </li>

                             <li class="menu-item-has-children">
                                 <a href="#">pages </a>
                                 <ul class="sub-menu">
                                     <li><a href="/blog">Blog</a></li>
                                     <li><a href="/about-us">About Us</a></li>
                                     <li><a href="/contact"> Contact Us</a></li>
                                     <li><a href="/privacy-policy">Privacy Policy</a></li>
                                     <li><a href="/refund-return">Refund Return</a></li>
                                     <li><a href="/shipping">Shipping</a></li>
                                     <li><a href="/terms">Terms</a></li>
                                     <li><a href="/ppf-terms">PPF Terms</a></li>
                                 </ul>
                             </li>
                         </ul>
                     </div>
                     <div class="offcanvas_footer">
                         <span><a href="#"><i class="fa fa-envelope-o"></i> info@yourdomain.com</a></span>
                         <ul>
                             <li><a href="/about-us">About Us</a></li>
                             <li><a href="/contact"> Contact Us</a></li>
                             <li><a href="/privacy-policy">Privacy Policy</a></li>
                             <li><a href="/refund-return">Refund Return</a></li>
                             <li><a href="/shipping">Shipping</a></li>
                             <li><a href="/terms">Terms</a></li>
                             <li><a href="/ppf-terms">PPF Terms</a></li>
                         </ul>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!--offcanvas menu area end-->

 <header>
     <div class="main_header">
         <!--header top start-->
         <div class="header_top">
             <div class="container">
                 <div class="row align-items-center">
                     <div class="col-lg-4 col-md-5">
                         <div class="header_account">
                             <ul>
                                 <li class="language"><a href="#"><img src="/assets/img/logo/language.png" alt=""> english <i class="ion-chevron-down"></i></a>
                                     <ul class="dropdown_language">
                                         <li><a href="#">English</a></li>

                                     </ul>
                                 </li>
                                 <li class="currency"><a href="#">INR <i class="ion-chevron-down"></i></a>
                                     <ul class="dropdown_currency">
                                         <li><a href="#">INR</a></li>

                                     </ul>
                                 </li>
                             </ul>
                         </div>
                     </div>
                     <div class="col-lg-8 col-md-7">
                         <div class="header_top_links text-right">
                             <ul>
                                 <li>
                                     <i class="icon-phone-call" aria-hidden="true"></i> <span>Call us : <a href="tel:+91 8252300400">+91 8252300400</a></span>
                                 </li>
                                 @if(!Auth::check()){
                                 <li><a href="/register">Register</a></li>}
                                 @endif

                                 @if(Auth::check())

                                 <li class="">
                                     Welcome {{ Auth::user()->name }}
                                 </li>
                                 <li class=""><a href="/dashboard"> | Go to Dashboard</li>
                                 <li>
                                     <form action="{{ route('logout') }}" method="POST">
                                         @csrf
                                         <button type="submit" class="nav-link btn btn-link">Logout</button>
                                     </form>
                                     @else
                                     <a href="{{ route('login') }}" class="text-white mx-2">Login</a>
                                     @endif
                                     </a>
                                 </li>
                                 <li><a href="/cart" class="text-white">Shopping Cart</a></li>
                             </ul>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <!--header top start-->

         <!--header middel start-->
         <div class="header_middle">
             <div class="container">
                 <div class="row align-items-center">
                     <div class="col-lg-2 col-md-4 col-sm-4 col-4">
                         <div class="logo">
                             <a href="/"><img src="/assets/Mafra-&-maxshine-combine-logo-2.png" style="max-width : 120% !important;" alt=""></a>
                         </div>
                     </div>
                     <div class="col-lg-10 col-md-6 col-sm-6 col-6">
                         <div class="header_right_box">
                             <div class="search_container">
                                 <form action="{{ route('searchQuery') }}" method="GET">
                                     <div class="hover_category">
                                         <select class="select_option" name="category" id="categori1">
                                             <option selected value="all">All Categories</option>
                                             <!-- <option value="BRANDS">BRANDS</option> -->
                                             @foreach($categories as $category)
                                             <option value="{{ (strtolower($category->name)) }}">{{ strtoupper($category->name) }}</option>
                                             @endforeach
                                         </select>
                                     </div>
                                     <div class="search_box">
                                         <input placeholder="Search product..." name="searchq" type="text" required>
                                         <button type="submit">Search</button>
                                     </div>
                                 </form>
                             </div>
                             <div class="header_configure_area">
                                 <div class="header_wishlist">
                                     @include('partials.wishlist_count')
                                 </div>
                                 @include('partials.mini_cart')

                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <!--header middel end-->

         <!--header bottom satrt-->
         <div class="header_bottom sticky-header">
             <div class="container">
                 <div class="row align-items-center">
                     <div class=" col-lg-3">
                         <div class="categories_menu">
                             <div class="categories_title">
                                 <h2 class="categori_toggle">ALL CATEGORIES</h2>
                             </div>
                             <div class="categories_menu_toggle">
                                 <ul>
                                     @foreach($categories as $category)
                                     <li class="menu_item_children">
                                         <a href="{{ route('products.category', Str::slug(strtolower($category->name))) }}">{{ strtoupper($category->name) }} <i class="fa fa-angle-right"></i></a>
                                         @if($category->subcategories->count())
                                         <ul class="categories_mega_menu column_2">
                                             @foreach($category->subcategories as $subcategory)
                                             <li class="menu_item_children">
                                                 <!-- <a href="#">{{ strtoupper($category->name) }}</a> -->
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="{{ route('products.subcategory', Str::slug(strtolower($subcategory->name))) }}">{{ $subcategory->name }}</a></li>
                                                 </ul>
                                             </li>
                                             @endforeach
                                         </ul>
                                         @endif
                                     </li>
                                     @endforeach
                                     <!-- <li><a href="#" id="more-btn"><i class="fa fa-plus" aria-hidden="true"></i>View All Categories</a></li> -->
                                 </ul>
                             </div>


                         </div>
                     </div>
                     <div class="col-lg-9">
                         <div class="main_menu menu_position text-left">
                             <nav>
                                 <ul>
                                     <!-- Home link remains static -->
                                     <li><a class="active" href="/">Home</a></li>

                                     <li>
                                         <a href="#">Shop By Brand <i class="fa fa-angle-down"></i></a>
                                         <ul class="sub_menu pages">
                                             <li><a href="/mafra">Mafra</a></li>
                                             <li><a href="/maxshine">Maxshine</a></li>
                                         </ul>
                                     </li>

                                     <!-- Dynamically load the first five categories -->
                                     @foreach($categories->take(5) as $category)
                                     <li>
                                         <a href="{{ route('products.category', $category->slug) }}">
                                             {{ strtoupper($category->name) }}
                                             @if($category->subcategories->count()) <i class="fa fa-angle-down"></i> @endif
                                         </a>

                                         @if($category->subcategories->count())
                                         <ul class="sub_menu pages">
                                             @foreach($category->subcategories as $subcategory)
                                             <li>
                                                 <a href="{{ route('products.subcategory', $subcategory->slug) }}">
                                                     {{ $subcategory->name }}
                                                 </a>
                                             </li>
                                             @endforeach
                                         </ul>
                                         @endif
                                     </li>
                                     @endforeach



                                     <!-- Pages section remains static -->
                                     <li>
                                         <a href="#">Pages <i class="fa fa-angle-down"></i></a>
                                         <ul class="sub_menu pages">
                                             <li><a href="/blog">Blog</a></li>
                                             <li><a href="/about-us">About Us</a></li>
                                             <li><a href="/contact">Contact Us</a></li>
                                             <li><a href="/privacy-policy">Privacy Policy</a></li>
                                             <li><a href="/refund-return">Refund Return</a></li>
                                             <li><a href="/shipping">Shipping</a></li>
                                             <li><a href="/terms">Terms</a></li>
                                             <li><a href="/ppf-terms">PPF Terms</a></li>
                                         </ul>
                                     </li>
                                 </ul>
                             </nav>


                         </div>
                     </div>

                 </div>
             </div>
         </div>
         <!--header bottom end-->
     </div>
 </header>
 <!--header area end-->
 <!-- Diwali Modal Start -->
 <!-- <div class="diwali-modal" id="diwaliModal">
     <div class="diwali-modal-content">
         <button class="diwali-modal-close" onclick="closeDiwaliModal()">×</button>
         <div class="diwali-modal-body">
             <img src="/assets/Diwali-Pop-up-banner.webp" alt="Diwali Celebration" class="img-fluid">
         </div>
     </div>
 </div> -->
 <!-- Diwali Modal End -->

 <style>
     /* Diwali Modal Styles */
     .diwali-modal {
         display: flex;
         align-items: center;
         justify-content: center;
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         height: 100%;
         background-color: rgba(0, 0, 0, 0.7);
         /* Semi-transparent background */
         z-index: 9999;
         visibility: hidden;
         /* Hidden by default */
         opacity: 0;
         transition: visibility 0s, opacity 0.3s;
     }

     .diwali-modal-content {
         position: relative;
         max-width: 500px;
         width: 100%;
         background: linear-gradient(to right, #FF6B00, #FFD700, #8B0000);
         padding: 20px;
         border-radius: 8px;
         overflow: hidden;
         box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
     }

     .diwali-modal-body {
         text-align: center;
     }

     .diwali-modal-close {
         position: absolute;
         top: 10px;
         right: 10px;
         background: #FF6B00;
         color: white;
         border: none;
         border-radius: 50%;
         width: 30px;
         height: 30px;
         font-size: 18px;
         cursor: pointer;
     }

     /* Show the modal */
     .diwali-modal.show {
         visibility: visible;
         opacity: 1;
     }
 </style>

 <script>
     // Function to open the modal
     function openDiwaliModal() {
         document.getElementById('diwaliModal').classList.add('show');
     }

     // Function to close the modal
     function closeDiwaliModal() {
         document.getElementById('diwaliModal').classList.remove('show');
     }

     // Optionally, auto-open the modal after a delay (e.g., 3 seconds)
     window.onload = function() {
         setTimeout(openDiwaliModal, 3000); // Open modal after 3 seconds
     };
 </script>