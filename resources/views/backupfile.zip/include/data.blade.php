 <!--header area start-->

 <!--offcanvas menu area start-->
 <div class="off_canvars_overlay">

 </div>
 <div class="offcanvas_menu">
     <div class="container">
         <div class="row">
             <div class="col-12">
                 <div class="canvas_open">
                     <a href="javascript:void(0)"><i class="ion-navicon"></i></a>
                 </div>
                 <div class="offcanvas_menu_wrapper">
                     <div class="canvas_close">
                         <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
                     </div>
                     <div class="call_support">
                         <p><i class="icon-phone-call" aria-hidden="true"></i> <span>Call us: <a href="tel:0123456789">0123456789</a></span></p>

                     </div>
                     <div class="header_account">
                         <ul>
                             <li class="language"><a href="#"><img src="assets/img/logo/language.png" alt=""> english <i class="ion-chevron-down"></i></a>
                                 <ul class="dropdown_language">
                                     <li><a href="#">English</a></li>
                                     <li><a href="#">Germany</a></li>
                                     <li><a href="#">Japanese</a></li>
                                 </ul>
                             </li>
                             <li class="currency"><a href="#">USD <i class="ion-chevron-down"></i></a>
                                 <ul class="dropdown_currency">
                                     <li><a href="#">EUR – Euro</a></li>
                                     <li><a href="#">GBP – British Pound</a></li>
                                     <li><a href="#">INR – India Rupee</a></li>
                                 </ul>
                             </li>
                         </ul>
                     </div>
                     <div class="header_top_links">
                         <ul>
                             <li><a href="/register">Register</a></li>
                             <li><a href="/login">login</a></li>
                             <li><a href="/cart">Shopping Cart</a></li>
                             <li><a href="/checkout">Checkout</a></li>
                         </ul>
                     </div>
                     <div class="search_container">
                         <form action="#">
                             <div class="hover_category">
                                 <select class="select_option" name="select" id="categori1">
                                     <option selected value="1">All Categories</option>
                                     <option value="2">Brands</option>
                                     <option value="3">Ceramic Coating</option>
                                     <option value="4">Ceramic Shampoos</option>
                                     <option value="5">Ceramic Waxes</option>
                                     <option value="6">PRE CERAMIC COMPOUND</option>
                                 </select>
                             </div>
                             <div class="search_box">
                                 <input placeholder="Search product..." type="text">
                                 <button type="submit">Search</button>
                             </div>
                         </form>
                     </div>
                     <div id="menu" class="text-left ">
                         <ul class="offcanvas_main_menu">
                             <li class="menu-item-has-children active">
                                 <a href="#">Home</a>
                                 <ul class="sub-menu">
                                     <li><a href="index.html">Home 1</a></li>
                                     <li><a href="index-2.html">Home 2</a></li>
                                     <li><a href="index-3.html">Home 3</a></li>
                                     <li><a href="index-4.html">Home 4</a></li>
                                 </ul>
                             </li>
                             <li class="menu-item-has-children">
                                 <a href="#">Shop</a>
                                 <ul class="sub-menu">
                                     <li class="menu-item-has-children">
                                         <a href="#">Shop Layouts</a>
                                         <ul class="sub-menu">
                                             <li><a href="shop.html">shop</a></li>
                                             <li><a href="shop-fullwidth.html">Full Width</a></li>
                                             <li><a href="shop-fullwidth-list.html">Full Width list</a></li>
                                             <li><a href="shop-right-sidebar.html">Right Sidebar </a></li>
                                             <li><a href="shop-right-sidebar-list.html"> Right Sidebar list</a></li>
                                             <li><a href="shop-list.html">List View</a></li>
                                         </ul>
                                     </li>
                                     <li class="menu-item-has-children">
                                         <a href="#">other Pages</a>
                                         <ul class="sub-menu">
                                             <li><a href="/cart">cart</a></li>
                                             <li><a href="wishlist.html">Wishlist</a></li>
                                             <li><a href="checkout.html">Checkout</a></li>
                                             <li><a href="my-account.html">my account</a></li>
                                             <li><a href="404.html">Error 404</a></li>
                                         </ul>
                                     </li>
                                     <li class="menu-item-has-children">
                                         <a href="#">Product Types</a>
                                         <ul class="sub-menu">
                                             <li><a href="product_details">product details</a></li>
                                             <li><a href="product-sidebar.html">product sidebar</a></li>
                                             <li><a href="product-grouped.html">product grouped</a></li>
                                             <li><a href="variable-product.html">product variable</a></li>
                                             <li><a href="product-countdown.html">product countdown</a></li>
                                         </ul>
                                     </li>
                                 </ul>
                             </li>
                             <li class="menu-item-has-children">
                                 <a href="#">blog</a>
                                 <ul class="sub-menu">
                                     <li><a href="blog.html">blog</a></li>
                                     <li><a href="blog-details.html">blog details</a></li>
                                     <li><a href="blog-fullwidth.html">blog fullwidth</a></li>
                                     <li><a href="blog-sidebar.html">blog sidebar</a></li>
                                     <li><a href="blog-no-sidebar.html">blog no sidebar</a></li>
                                 </ul>

                             </li>
                             <li class="menu-item-has-children">
                                 <a href="#">pages </a>
                                 <ul class="sub-menu">
                                     <li><a href="about.html">About Us</a></li>
                                     <li><a href="faq.html">Frequently Questions</a></li>
                                     <li><a href="contact.html">contact</a></li>
                                     <li><a href="/login">login</a></li>
                                     <li><a href="404.html">Error 404</a></li>
                                     <li><a href="compare.html">compare</a></li>
                                     <li><a href="privacy-policy.html">privacy policy</a></li>
                                     <li><a href="coming-soon.html">coming soon</a></li>
                                 </ul>
                             </li>
                             <li class="menu-item-has-children">
                                 <a href="my-account.html">my account</a>
                             </li>
                             <li class="menu-item-has-children">
                                 <a href="about.html">About Us</a>
                             </li>
                             <li class="menu-item-has-children">
                                 <a href="contact.html"> Contact Us</a>
                             </li>
                         </ul>
                     </div>
                     <div class="offcanvas_footer">
                         <span><a href="#"><i class="fa fa-envelope-o"></i> info@yourdomain.com</a></span>
                         <ul>
                             <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                             <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                             <li class="pinterest"><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                             <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                             <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                         </ul>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!--offcanvas menu area end-->

 <header>
     <div class="main_header">
         <!--header top start-->
         <div class="header_top">
             <div class="container">
                 <div class="row align-items-center">
                     <div class="col-lg-4 col-md-5">
                         <div class="header_account">
                             <ul>
                                 <li class="language"><a href="#"><img src="assets/img/logo/language.png" alt=""> english <i class="ion-chevron-down"></i></a>
                                     <ul class="dropdown_language">
                                         <li><a href="#">English</a></li>
                                         <li><a href="#">Germany</a></li>
                                         <li><a href="#">Japanese</a></li>
                                     </ul>
                                 </li>
                                 <li class="currency"><a href="#">USD <i class="ion-chevron-down"></i></a>
                                     <ul class="dropdown_currency">
                                         <li><a href="#">EUR – Euro</a></li>
                                         <li><a href="#">GBP – British Pound</a></li>
                                         <li><a href="#">INR – India Rupee</a></li>
                                     </ul>
                                 </li>
                             </ul>
                         </div>
                     </div>
                     <div class="col-lg-8 col-md-7">
                         <div class="header_top_links text-right">
                             <ul>


                                 @if(!Auth::check()){
                                 <li><a href="/register">Register</a></li>}
                                 @endif
                                 <li><a href="/login"></li>
                                 <li class="mr-4">


                                     @if(Auth::check())
                                     Welcome {{ Auth::user()->name }}
                                 </li>
                                 <li>

                                     <form action="{{ route('logout') }}" method="POST">
                                         @csrf
                                         <button type="submit" class="nav-link btn btn-link">Logout</button>
                                     </form>
                                     @else
                                     <a href="{{ route('login') }}">Login</a>
                                     @endif
                                     </a>
                                 </li>
                                 <li><a href="/cart">Shopping Cart</a></li>
                             </ul>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <!--header top start-->

         <!--header middel start-->
         <div class="header_middle">
             <div class="container">
                 <div class="row align-items-center">
                     <div class="col-lg-2 col-md-4 col-sm-4 col-4">
                         <div class="logo">
                             <a href="index.html"><img src="assets/img/logo/logo-2.webp" alt=""></a>
                         </div>
                     </div>
                     <div class="col-lg-10 col-md-6 col-sm-6 col-6">
                         <div class="header_right_box">
                             <div class="search_container">
                                 <form action="#">
                                     <div class="hover_category">
                                         <select class="select_option" name="select" id="categori2">
                                             <option selected value="1">All Categories</option>
                                             <option value="2">Ceramic Series</option>
                                             <option value="3">Ceramic Coating</option>
                                             <option value="4">Ceramic Shampoos</option>
                                             <option value="5">Ceramic Waxes</option>
                                             <option value="6">PRE CERAMIC COMPOUND</option>
                                         </select>
                                     </div>
                                     <div class="search_box">
                                         <input placeholder="Search product..." type="text">
                                         <button type="submit">Search</button>
                                     </div>
                                 </form>
                             </div>
                             <div class="header_configure_area">
                                 <div class="header_wishlist">
                                     <a href="wishlist.html"><i class="icon-heart"></i>
                                         <span class="wishlist_count">3</span>
                                     </a>
                                 </div>
                                 <div class="mini_cart_wrapper">
                                     <a href="javascript:void(0)">
                                         <i class="icon-shopping-bag2"></i>
                                         <span class="cart_price">$152.00 <i class="ion-ios-arrow-down"></i></span>
                                         <span class="cart_count">2</span>
                                     </a>
                                     <!--mini cart-->
                                     <div class="mini_cart">
                                         <div class="mini_cart_inner">
                                             <div class="cart_close">
                                                 <div class="cart_text">
                                                     <h3>cart</h3>
                                                 </div>
                                                 <div class="mini_cart_close">
                                                     <a href="javascript:void(0)"><i class="icon-x"></i></a>
                                                 </div>
                                             </div>
                                             <div class="cart_item">
                                                 <div class="cart_img">
                                                     <a href="#"><img src="assets/img/s-product/product.jpg" alt=""></a>
                                                 </div>
                                                 <div class="cart_info">
                                                     <a href="#">Fusce Aliquam</a>
                                                     <p>Qty: 1 X <span> $60.00 </span></p>
                                                 </div>
                                                 <div class="cart_remove">
                                                     <a href="#"><i class="ion-android-close"></i></a>
                                                 </div>
                                             </div>
                                             <div class="cart_item">
                                                 <div class="cart_img">
                                                     <a href="#"><img src="assets/img/s-product/product2.jpg" alt=""></a>
                                                 </div>
                                                 <div class="cart_info">
                                                     <a href="#">Ras Neque Metus</a>
                                                     <p>Qty: 1 X <span> $60.00 </span></p>
                                                 </div>
                                                 <div class="cart_remove">
                                                     <a href="#"><i class="ion-android-close"></i></a>
                                                 </div>
                                             </div>

                                             <div class="mini_cart_table">
                                                 <div class="cart_total">
                                                     <span>Sub total:</span>
                                                     <span class="price">$138.00</span>
                                                 </div>
                                                 <div class="cart_total mt-10">
                                                     <span>total:</span>
                                                     <span class="price">$138.00</span>
                                                 </div>
                                             </div>
                                         </div>
                                         <div class="mini_cart_footer">
                                             <div class="cart_button">
                                                 <a href="/cart">View cart</a>
                                             </div>
                                             <div class="cart_button">
                                                 <a class="active" href="checkout.html">Checkout</a>
                                             </div>

                                         </div>
                                     </div>
                                     <!--mini cart end-->
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <!--header middel end-->

         <!--header bottom satrt-->
         <div class="header_bottom sticky-header">
             <div class="container">
                 <div class="row align-items-center">
                     <div class=" col-lg-3">
                         <div class="categories_menu">
                             <div class="categories_title">
                                 <h2 class="categori_toggle">ALL CATEGORIES</h2>
                             </div>
                             <div class="categories_menu_toggle">
                                 <ul>
                                     <li class="menu_item_children"><a href="#">BRANDS <i class="fa fa-angle-right"></i></a>
                                         <ul class="categories_mega_menu column_2">
                                             <li class="menu_item_children"><a href="#">Our Brands</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="categories">MaxShine</a></li>
                                                     <li><a href="categories">Mafra</a></li>
                                                 </ul>
                                             </li>
                                             <li class="menu_item_children"><a href="#">Our Brands</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="categories">Maniac</a></li>
                                                 </ul>
                                             </li>

                                         </ul>
                                     </li>
                                     <li class="menu_item_children"><a href="#">INTERIOR <i class="fa fa-angle-right"></i></a>
                                         <ul class="categories_mega_menu column_2">
                                             <li class="menu_item_children"><a href="#">Cleaners</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="categories">All Purpose Cleaners</a></li>
                                                     <li><a href="categories">Glass Cleaners</a></li>
                                                 </ul>
                                             </li>
                                             <li class="menu_item_children"><a href="#">Dressing</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="categories">RUBBER / PLASTIC / VINYL</a></li>
                                                     <li><a href="categories">LEATHER CONDITIONERS</a></li>
                                                     <li><a href="categories">SAMPLE KIT</a></li>
                                                 </ul>
                                             </li>
                                         </ul>
                                     </li>

                                     <li class="menu_item_children"><a href="#">EXTERIOR <i class="fa fa-angle-right"></i></a>
                                         <ul class="categories_mega_menu column_2">
                                             <li class="menu_item_children"><a href="#">WASH & RESTORE</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="categories">CAR WASH SHAMPOOS</a></li>
                                                     <li><a href="categories">CLAY DECON</a></li>
                                                     <li><a href="#">TAR REMOVERS </a></li>
                                                     <li><a href="#">WHEEL / TYRE CLEANERS</a></li>
                                                     <li><a href="#">ENGINE DEGREASERS</a></li>
                                                     <li><a href="#">RUBBER / PLASTIC / VINYL</a></li>
                                                     <li><a href="#">SAMPLE KIT </a></li>
                                                     <li><a href="#">GLASS CARE</a></li>
                                                 </ul>
                                             </li>
                                             <li class="menu_item_children"><a href="#">GLASS CLEANERS</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="#">HARD WATER SCALE REMOVERS</a></li>
                                                     <li><a href="#">GLASS POWDERS</a></li>
                                                     <li><a href="#">GLASS PADS</a></li>
                                                 </ul>
                                             </li>
                                         </ul>
                                     </li>



                                     <li class="menu_item_children"><a href="#"> PAINT CARE<i class="fa fa-angle-right"></i></a>
                                         <ul class="categories_mega_menu column_3">
                                             <li class="menu_item_children"><a href="#">PAINT CORRECTION</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="#">POLISHERS & KITS</a></li>
                                                     <li><a href="#">COMPOUNDS & POLISHES</a></li>
                                                     <li><a href="#">FOAM / WOOL PADS </a></li>
                                                     <li><a href="#">SANDING TOOLS</a></li>
                                                     <li><a href="#">BACKING PLATES</a></li>
                                                     <li><a href="#">METAL & CHROME</a></li>
                                                     <li><a href="#">MASKING TAPES</a></li>
                                                     <li><a href="#">DIGITAL GAUGE</a></li>
                                                 </ul>
                                             </li>
                                             <li class="menu_item_children"><a href="#">CERAMIC COATING</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="#">PAINT COATINGS</a></li>
                                                     <li><a href="#">GLASS COATINGS</a></li>
                                                     <li><a href="#">ALLOY COATINGS</a></li>
                                                     <li><a href="#">TRIM COATINGS</a></li>
                                                     <li><a href="#">LEATHER COATINGS</a></li>
                                                     <li><a href="#">FABRIC COATINGS</a></li>
                                                     <li><a href="#">IPA CLEANERS</a></li>
                                                     <li><a href="#">HYBRID WAX / SEALANTS</a></li>
                                                 </ul>
                                             </li>
                                             <li class="menu_item_children"><a href="#">PPF</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="#">PAINT PROTECTION FILMS</a></li>
                                                     <li><a href="#">DOOR EDGES</a></li>
                                                 </ul>
                                             </li>
                                         </ul>
                                     </li>
                                     <li class="menu_item_children"><a href="#"> MACHINES & TOOLS<i class="fa fa-angle-right"></i></a>
                                         <ul class="categories_mega_menu column_3">
                                             <li class="menu_item_children"><a href="#">POLISHERS</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="#">DUAL ACTION POLISHERS</a></li>
                                                     <li><a href="#">ROTARY POLISHERS</a></li>
                                                     <li><a href="#">CORDLESS POLISHERS</a></li>
                                                 </ul>
                                             </li>
                                             <li class="menu_item_children"><a href="#">DETAILING MACHINES</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="#">STEAM MACHINES</a></li>
                                                     <li><a href="#">VACUUM MACHINES</a></li>
                                                     <li><a href="#">OZONE PURIFIERS</a></li>
                                                     <li><a href="#">AIR COMPRESSORS</a></li>
                                                     <li><a href="#">PRESSURE WASHERS</a></li>
                                                 </ul>
                                             </li>
                                             <li class="menu_item_children"><a href="#">ATTACHMENTS</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="#">FOAM LANCE / FOAMERS</a></li>
                                                     <li><a href="#">SPINDLE / ADAPTER / BRUSHES</a></li>
                                                     <li><a href="#">EXTENSION CABLES</a></li>
                                                 </ul>
                                             </li>
                                         </ul>
                                     </li>
                                     <li class="menu_item_children"><a href="#"> DETALINMG & TOOLS<i class="fa fa-angle-right"></i></a>
                                         <ul class="categories_mega_menu column_2">
                                             <li class="menu_item_children"><a href="#">POLISHERS</a>
                                                 <ul class="categorie_sub_menu">
                                                     <li><a href="#">MICROFIBERS</a></li>
                                                     <li><a href="#">FOAMER & SPRAY BOTTLES</a></li>
                                                     <li><a href="#">CLEANING BRUSHES</a></li>
                                                     <li><a href="#">WAX / DRESSING APPLICATORS</a></li>
                                                 </ul>
                                             </li>

                                             <ul class="categorie_sub_menu">
                                                 <li><a href="#">WASH MITTS</a></li>
                                                 <li><a href="#">STORE ORGANIZERS</a></li>
                                                 <li><a href="#">INTERIOR SCRUBBING PADS</a></li>
                                             </ul>
                                     </li>
                                 </ul>
                                 </li>
                                 <li><a href="#" id="more-btn"><i class="fa fa-plus" aria-hidden="true"></i>View All Categories</a></li>
                                 </ul>
                             </div>
                         </div>
                     </div>
                     <div class="col-lg-9">
                         <div class="main_menu menu_position text-left">
                             <nav>
                                 <ul>
                                     <li><a class="active" href="/">Home</a></li>
                                     <li class="mega_items"><a href="shop.html">BRANDS<i class="fa fa-angle-down"></i></a>

                                         <ul class="sub_menu pages">
                                             <li><a href="#">OUR BRANDS</a>
                                                 <ul>
                                                     <li><a href="#">Maxshine</a></li>
                                                     <li><a href="#">Mafra</a></li>
                                                     <li><a href="#">Maniac</a></li>
                                                 </ul>
                                             </li>
                                         </ul>
                                     </li>
                                     <li><a href="#">INTERIOR <i class="fa fa-angle-down"></i></a>
                                         <ul class="sub_menu pages">
                                             <li><a href="#">All Purpose Cleaners</a></li>
                                             <li><a href="#">Glass Cleaners</a></li>
                                             <li><a href="#">RUBBER / PLASTIC / VINYL</a></li>
                                             <li><a href="#">LEATHER CONDITIONERS</a></li>
                                             <li><a href="#">SAMPLE KIT</a></li>

                                         </ul>
                                     </li>
                                     <li><a href="#">EXTERIOR <i class="fa fa-angle-down"></i></a>
                                         <ul class="sub_menu pages">
                                             <li class="menu_item_children"><a href="#">WASH & RESTORE</a></li>
                                             <li><a href="#">CAR WASH SHAMPOOS</a></li>
                                             <li><a href="#">CLAY DECON</a></li>
                                             <li><a href="#">TAR REMOVERS </a></li>
                                             <li><a href="#">WHEEL / TYRE CLEANERS</a></li>
                                             <li><a href="#">ENGINE DEGREASERS</a></li>
                                             <li><a href="#">RUBBER / PLASTIC / VINYL</a></li>
                                             <li><a href="#">SAMPLE KIT </a></li>
                                             <li><a href="#">GLASS CARE</a></li>
                                             <li class="menu_item_children"><a href="#">GLASS CLEANERS</a></li>
                                             <li><a href="#">HARD WATER SCALE REMOVERS</a></li>
                                             <li><a href="#">GLASS POWDERS</a></li>
                                             <li><a href="#">GLASS PADS</a></li>
                                         </ul>
                                     </li>

                                     <li class="mega_items"><a href="#">PAINT CARE<i class="fa fa-angle-down"></i></a>
                                         <div class="mega_menu">
                                             <ul class="mega_menu_inner">
                                                 <li><a href="#">PAINT CORRECTION</a>
                                                     <ul>
                                                         <li><a href="#">POLISHERS & KITS</a></li>
                                                         <li><a href="#">COMPOUNDS & POLISHES</a></li>
                                                         <li><a href="#">FOAM / WOOL PADS </a></li>
                                                         <li><a href="#">SANDING TOOLS</a></li>
                                                         <li><a href="#">BACKING PLATES</a></li>
                                                         <li><a href="#">METAL & CHROME</a></li>
                                                         <li><a href="#">MASKING TAPES</a></li>
                                                         <li><a href="#">DIGITAL GAUGE</a></li>
                                                     </ul>
                                                 </li>
                                                 <li><a href="#">CERAMIC COATING</a>
                                                     <ul>
                                                         <li><a href="#">PAINT COATINGS</a></li>
                                                         <li><a href="#">GLASS COATINGS</a></li>
                                                         <li><a href="#">ALLOY COATINGS</a></li>
                                                         <li><a href="#">TRIM COATINGS</a></li>
                                                         <li><a href="#">LEATHER COATINGS</a></li>
                                                         <li><a href="#">FABRIC COATINGS</a></li>
                                                         <li><a href="#">IPA CLEANERS</a></li>
                                                         <li><a href="#">HYBRID WAX / SEALANTS</a></li>
                                                     </ul>
                                                 </li>

                                                 <li><a href="#">PPF</a>
                                                     <ul class="categorie_sub_menu">
                                                         <li><a href="#">PAINT PROTECTION FILMS</a></li>
                                                         <li><a href="#">DOOR EDGES</a></li>
                                                     </ul>
                                                 </li>

                                             </ul>
                                         </div>
                                     </li>

                                     <li class="mega_items"><a href="#">MACHINES<i class="fa fa-angle-down"></i></a>
                                         <div class="mega_menu">
                                             <ul class="mega_menu_inner">
                                                 <li><a href="#">POLISHERS</a>
                                                     <ul>
                                                         <li><a href="#">DUAL ACTION POLISHERS</a></li>
                                                         <li><a href="#">ROTARY POLISHERS</a></li>
                                                         <li><a href="#">CORDLESS POLISHERS</a></li>
                                                     </ul>
                                                 </li>
                                                 <li><a href="#">DETAILING MACHINES</a>
                                                     <ul>
                                                         <li><a href="#">STEAM MACHINES</a></li>
                                                         <li><a href="#">VACUUM MACHINES</a></li>
                                                         <li><a href="#">OZONE PURIFIERS</a></li>
                                                         <li><a href="#">AIR COMPRESSORS</a></li>
                                                         <li><a href="#">PRESSURE WASHERS</a></li>
                                                     </ul>
                                                 </li>

                                                 <li><a href="#">ATTACHMENTS</a>
                                                     <ul class="categorie_sub_menu">
                                                         <li><a href="#">FOAM LANCE / FOAMERS</a></li>
                                                         <li><a href="#">SPINDLE / ADAPTER / BRUSHES</a></li>
                                                         <li><a href="#">EXTENSION CABLES</a></li>
                                                     </ul>
                                                 </li>
                                             </ul>
                                         </div>
                                     </li>
                                     <li><a href="#">DETALING <i class="fa fa-angle-down"></i></a>
                                         <ul class="sub_menu pages">
                                             <li><a href="#">MICROFIBERS</a></li>
                                             <li><a href="#">FOAMER & SPRAY BOTTLES</a></li>
                                             <li><a href="#">CLEANING BRUSHES</a></li>
                                             <li><a href="#">WAX / DRESSING APPLICATORS</a></li>
                                             <li><a href="#">WASH MITTS</a></li>
                                             <li><a href="#">STORE ORGANIZERS</a></li>
                                             <li><a href="#">INTERIOR SCRUBBING PADS</a></li>
                                             <li><a href="#">FOAM LANCE / FOAMERS</a></li>
                                             <li><a href="#">SPINDLE / ADAPTER / BRUSHES</a></li>
                                             <li><a href="#">EXTENSION CABLES</a></li>
                                         </ul>
                                     </li>

                                     <li><a href="#">pages <i class="fa fa-angle-down"></i></a>
                                         <ul class="sub_menu pages">
                                             <li><a href="about.html">About Us</a></li>
                                             <li><a href="contact.html"> Contact Us</a></li>
                                             <li><a href="faq.html">Frequently Questions</a></li>
                                             <li><a href="compare.html">Blog</a></li>
                                         </ul>
                                     </li>
                                 </ul>
                             </nav>
                         </div>
                     </div>

                 </div>
             </div>
         </div>
         <!--header bottom end-->
     </div>
 </header>
 <!--header area end-->