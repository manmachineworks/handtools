<!--footer area start-->
<footer class="footer_widgets">

    <div class="footer_top">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="widgets_container">
                        <h3>CONTACT INFO</h3>
                        <div class="footer_contact">
                            <div class="footer_contact_inner">
                                <div class="contact_icone">
                                    <img src="assets/img/icon/icon-phone.png" alt="">
                                </div>
                                <div class="contact_text">
                                    <p>Hotline Free 24/7: <br> <strong><a href="tel:+918252300400">+91 8252300400</a> </strong></p>
                                </div>
                            </div>
                            <p>Driven by passion and innovation, we deliver exceptional automotive care products for a cleaner, shinier, and more protected vehicle experience.</p>
                            <p>D-120, Sector-63, Noida
                                - 201301 <br> info@mafraindia.com</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="footer_col_container">
                        <div class="widgets_container">
                            <h3>Information</h3>
                            <div class="footer_menu">
                                <ul>
                                    <li><a href="/about-us">About Us</a></li>
                                    <li><a href="/refund-return">Refund Return</a></li>
                                    <li><a href="/shipping">Shipping</a></li>
                                    <li><a href="/terms">Terms</a></li>
                                    <li><a href="/ppf-terms">PPF Terms</a></li>
                                    <li><a href="/privacy-policy">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="footer_col_container">
                        <div class="widgets_container">
                            <h3>Categories</h3>
                            <div class="footer_menu">
                                <ul>
                                    <li><a href="/category/interior">Interior</a></li>
                                    <li><a href="/category/exterior">Exterior</a></li>
                                    <li><a href="/category/paint-care">Paint Care</a></li>
                                    <li><a href="/category/machines-tools">Machines Tools</a></li>
                                    <li><a href="/category/detailing-tools">Detailing Tools</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="newsletter_container">
                        <h3 class="text-white">Newsletter Now</h3>
                        <p class="text-white">Join 60.000+ subscribers and get a new discount coupon on every Wednesday.</p>
                        <div class="subscribe_form">
                            <form method="post" action="/subscribe" class="mc-form footer-newsletter">
                                @csrf
                                <input type="email" id="sub_mail" name="sub_mail" autocomplete="off" placeholder="Enter you email address here..." />

                                <button type="submit" class="btn btn-outline-primary ">Subscribe</button>
                            </form>
                            <!-- mailchimp-alerts Start -->
                            <div class="mailchimp-alerts text-centre">
                                <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                                <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                                <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                            </div><!-- mailchimp-alerts end -->
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="footer_bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6">
                    <div class="copyright_area">
                        <p>&copy; 2024 <a href="#" class="text-uppercase">Mafra India</a>. Made with <i class="fa fa-heart"></i> by <a target="_blank" href="https://manmachineworks.com/">Man Machien Works</a> || <a target="_blank" href="https://www.exppresscarwash.com/blog/top-25-car-detailing-franchise-to-own-2023/">Car Detaling Franchise</a></p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="footer_payment text-right">
                        <img src="assets/img/icon/payment.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--footer area end-->








<!-- JS
============================================ -->

<!-- Plugins JS -->
<script src="/assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="/assets/js/main.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            let alert = document.querySelector('.alert');
            if (alert) {
                let bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 3000); // 3000ms = 3 seconds
    });
</script>
@if(session('product') && session('quantity'))
<script>
    const product = @json(session('product')); // Blade correctly converts PHP object to JS object
    const quantity = {
        {
            session('quantity')
        }
    }; // Blade converts the session quantity to a number
    const variant = @json(session('variant')); // Blade converts variant object (or null)

    // Debugging to see values are correctly passed
    console.log("Product:", product);
    console.log("Quantity:", quantity);
    console.log("Variant:", variant);


    // gtag('event', 'add_to_cart', {
    //     currency: 'INR', // Currency
    //     value: parseFloat(product.sale_price) * quantity, // Dynamically calculate total price
    //     items: [{
    //         item_id: product.id.toString(), // Ensure item_id is a string
    //         item_name: product.product_name, // Product name
    //         variant_id: variant ? variant.id.toString() : null, // Handle null variant
    //         price: parseFloat(product.sale_price), // Price as a number
    //         quantity: quantity // Quantity as a number
    //     }]
    // });

    gtag("event", "add_to_cart", {
        currency: "USD",
        value: 30.03,
        items: [{
            item_id: "SKU_12345",
            item_name: "Stan and Friends Tee",
            affiliation: "Google Merchandise Store",
            coupon: "SUMMER_FUN",
            discount: 2.22,
            index: 0,
            item_brand: "Google",
            item_category: "Apparel",
            item_category2: "Adult",
            item_category3: "Shirts",
            item_category4: "Crew",
            item_category5: "Short sleeve",
            item_list_id: "related_products",
            item_list_name: "Related Products",
            item_variant: "green",
            location_id: "ChIJIQBpAG2ahYAR_6128GcTUEo",
            price: 10.01,
            quantity: 3
        }]
    });
</script>
@endif

<script>
    @if(session('cart_event'))
    const product = @json(session('product'));
    const quantity = {
        {
            session('quantity', 1)
        }
    };
    const variant = @json(session('variant'));

    console.log("Product:", product);
    console.log("Quantity:", quantity);
    console.log("Variant:", variant);

    // Trigger the Google Analytics add_to_cart event
    gtag('event', 'add_to_cart', {
        currency: 'INR',
        value: parseFloat(product.sale_price) * quantity,
        items: [{
            item_id: product.id.toString(),
            item_name: product.product_name,
            variant_id: variant ? variant.id.toString() : null,
            price: parseFloat(product.sale_price),
            quantity: quantity
        }]
    });
    @endif
</script>

<script>
    const product = @json(session('product'));
    const quantity = {
        session('quantity', 1)
    };
    const variant = @json(session('variant'));

    gtag("event", "add_to_cart", {
        currency: "INR",
        value: 30.03,
        items: [{
            item_id: "SKU_12345",
            item_name: "Stan and Friends Tee",
            affiliation: "Google Merchandise Store",
            coupon: "SUMMER_FUN",
            discount: 2.22,
            index: 0,
            item_brand: "Google",
            item_category: "Apparel",
            item_category2: "Adult",
            item_category3: "Shirts",
            item_category4: "Crew",
            item_category5: "Short sleeve",
            item_list_id: "related_products",
            item_list_name: "Related Products",
            item_variant: "green",
            location_id: "ChIJIQBpAG2ahYAR_6128GcTUEo",
            price: 10.01,
            quantity: 3
        }]
    });
</script>

@if(session() -> has('cart_event'))
<script>
    // Correctly fetch session data and ensure it's logged
    const product = @json(session('product')); // Fetch 'product' session as JSON
    const quantity = @json(session('quantity', 1)); // Fetch 'quantity' session value as JSON (defaults to 1)
    const variant = @json(session('variant', null)); // Handle 'variant' as JSON with null fallback

    // Debugging to ensure values are correct
    console.log("Product:", product);
    console.log("Quantity:", quantity);
    console.log("Variant:", variant);

    // Make sure to safely trigger the gtag event with dynamic values
    gtag("event", "add_to_cart", {
        currency: "INR", // Your currency
        value: parseFloat(product.sale_price) * quantity, // Calculate total value dynamically
        items: [{
            item_id: product.id.toString(), // Convert product ID to string
            item_name: product.product_name, // Product name from session
            item_brand: "Mafra India", // Static or dynamic value for brand
            item_category: product.category, // Static or dynamic category
            item_variant: variant ? variant.name : "Default Variant", // Use variant or fallback
            price: parseFloat(product.sale_price), // Product price as a number
            quantity: quantity // Quantity from session
        }]
    });
</script>
@endif
@if(session()->has('cart_event'))
@php
// Clear the cart event session variable
session()->forget('cart_event');
@endphp
@endif
<script>
    // Check if 'product' session exists
    console.log('Product session is live:', @json(session('product')));

    // Check if 'variant' session exists
    @if(session() -> has('variant'))
    console.log('Variant session is live:', @json(session('variant')));
    @else
    console.log('Variant session is not live.');
    @endif

    // Check if 'quantity' session exists
    @if(session() -> has('quantity'))
    console.log('Quantity session is live:', @json(session('quantity', 1)));
    @else
    console.log('Quantity session is not live.');
    @endif

    // Check if 'cart_event' session exists
    @if(session() -> has('cart_event'))
    console.log('Cart event session is live:', @json(session('cart_event')));
    @else
    console.log('Cart event session is not live.');
    @endif
</script>