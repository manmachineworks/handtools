<!doctype html>
<html class="no-js" lang="en">
@include("include/head")

<body>
    @include("include/header")
    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>contact us</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->

    <div class="contact_page_bg">
        <!--contact map start-->
        <div class="contact_map">
            <div class="map-area">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14008.675460793313!2d77.37625866603027!3d28.62470064583655!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cefd40ed1d95d%3A0xcdddd31c43e598b4!2sManmachine%20Automotive%20Pvt.%20Ltd.%20%7C%20Sector%2063%2C%20Noida!5e0!3m2!1sen!2sin!4v1721626200299!5m2!1sen!2sin" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

            </div>
        </div>
        <!--contact map end-->
        <div class="container">
            <!--contact area start-->
            <div class="contact_area">
                <div class="row">
                    <div class="col-lg-6 col-md-12">
                        <div class="contact_message content">
                            <h3>contact us</h3>
                            <p>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram anteposuerit litterarum formas human. qui sequitur mutationem consuetudium lectorum. Mirum est notare quam</p>
                            <ul>
                                <li><i class="fa fa-fax"></i> Address : D-120, SECTOR-63, NOIDA – 201301, U.P, INDIA</li>
                                <li><i class="fa fa-phone"></i> <a href="#">info@mafraindia.com</a></li>
                                <li><i class="fa fa-envelope-o"></i> +91 8252300400</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="contact_message form">
                            <h3>Contact Form</h3>
                            <form method="POST" action="{{ route('contact.store') }}">
                                @csrf
                                <p>
                                    <label> Your Name (required)</label>
                                    <input name="name" placeholder="Name *" type="text">
                                </p>
                                <p>
                                    <label> Your Email (required)</label>
                                    <input name="email" placeholder="Email *" type="email">
                                </p>
                                <p>
                                    <label> Subject</label>
                                    <input name="subject" placeholder="Subject *" type="text">
                                </p>
                                <div class="contact_textarea">
                                    <label> Your Message</label>
                                    <textarea placeholder="Message *" name="message" class="form-control2"></textarea>
                                </div>
                                <button type="submit"> Send</button>
                                <p class="form-messege"></p>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <!--contact area end-->
        </div>
    </div>




    @include("include/footer")
</body>

</html>