<!doctype html>
<html class="no-js" lang="en">


@include('include/head')
<meta name="csrf-token" content="{{ csrf_token() }}">
<style>
    .form-check {
        margin-bottom: 15px;
    }

    .form-check-label {
        margin-left: 10px;
    }

    .form-check-input {
        margin-right: 10px;
    }

    .card-header,
    .card-footer {
        background-color: #f8f9fa;
        border-bottom: 1px solid #e9ecef;
    }
</style>

<body>

    @include('include/header')

    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="/">home</a></li>
                            <li>Checkout</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs area end-->
    <!--shopping cart area start -->
    <div class="cart_page_bg">
        <div class="container">
            <div class="shopping_cart_area">
                <div class="row">
                    <div class="col-12">
                        <div class="table_desc">
                            <div class="cart_page">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="product_thumb">Image</th>
                                            <th class="product_name">Product</th>
                                            <th class="product_variant">Variant</th>
                                            <th class="product-price">Price</th>
                                            <th class="product_quantity">Quantity</th>
                                            <th class="product_total">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($cart as $item)
                                        <tr>
                                            <td class="product_thumb">
                                                <a href="{{ route('product.show', $item->product->url) }}">
                                                    <img src="{{ asset($item->variant ? $item->variant->variantImages->first()->image_url : $item->product->images->first()->image_url) }}"
                                                        alt="{{ $item->product->product_name }}">
                                                </a>
                                            </td>
                                            <td class="product_name">
                                                <a
                                                    href="{{ route('product.show', $item->product->url) }}">{{ $item->product->product_name }}</a>
                                            </td>
                                            <td class="product_variant">
                                                <label>Variant</label>
                                                <p>{{ $item->variant ? $item->variant->variant : 'Default' }}</p>
                                            </td>
                                            <td class="product-price">
                                                INR
                                                {{ $item->variant ? $item->variant->sale_price : $item->product->sale_price }}
                                            </td>
                                            <td class="product_quantity">
                                                Product Quantity : {{ $item->quantity }}
                                            </td>
                                            <td class="product_total">
                                                INR
                                                {{ $item->variant ? $item->variant->sale_price : $item->product->sale_price }}
                                                x {{ $item->quantity }}
                                            </td>
                                        </tr>
                                        @empty
                                        <tr>
                                            <td colspan="8">Your cart is empty.</td>
                                        </tr>
                                        @endforelse

                                    </tbody>
                                </table>

                            </div>


                        </div>
                    </div>
                </div>


                <div class="coupon_area ">
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="coupon_code right">

                                <div class="coupon_inner">
                                    <h3>Cart Total</h3>
                                    <div class="coupon_inner">
                                        @php
                                        $couponApplied = session('coupon_applied');
                                        $successMessage = session('success');
                                        $errorMessage = session('error');
                                        @endphp

                                        @if ($couponApplied)
                                        <div class="alert alert-success">
                                            Coupon code "{{ session('coupon_code') }}" has been applied
                                            successfully.
                                        </div>
                                        <div class="p-1">
                                            <h4>Coupon Applied</h4> <b>{{ session('coupon_code') }}</b>
                                        </div>
                                        @elseif($successMessage)
                                        <div class="alert alert-success">
                                            {{ $successMessage }}
                                        </div>
                                        @elseif($errorMessage)
                                        <div class="alert alert-danger">
                                            {{ $errorMessage }}
                                        </div>
                                        @else
                                        <form action="{{ route('apply.coupon') }}" method="POST">
                                            @csrf
                                            <div class="form-group">
                                                <label for="coupon_code">Coupon code</label>
                                                <input type="text" name="coupon_code" id="coupon_code"
                                                    placeholder="Enter coupon code" class="form-control my-4">
                                            </div>
                                            <button type="submit" class="btn btn-primary my-2">Apply
                                                coupon</button>
                                        </form>
                                        @endif
                                    </div>
                                    <div class="cart_subtotal">

                                        <p class="cart_amount"> @include('partials.disc_cart')</p>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="coupon_code right p-4">
                                <h3>Checkout</h3>
                                @if (Auth::check())
                                @if (Auth::user()->addresses->isEmpty())
                                <!-- User has no saved addresses, show the add address form -->
                                <div class="col-md-12 mb-3">
                                    <form action="{{ route('add_address') }}" method="POST">
                                        @csrf
                                        <div class="row">
                                            <div class="col-md-4 mb-3">
                                                <label for="first_name">First Name (optional)</label>
                                                <input type="text" class="form-control" id="first_name"
                                                    name="first_name" placeholder="First name">
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label for="last_name">Last Name</label>
                                                <input type="text" class="form-control" id="last_name"
                                                    name="last_name" placeholder="Last name" required>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label for="country">Country</label>
                                                <select class="form-control" id="country" name="country"
                                                    required>
                                                    <option value="India">India</option>
                                                    <!-- Add more countries as needed -->
                                                </select>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label for="address">Address</label>
                                                <input type="text" class="form-control" id="address"
                                                    name="address" placeholder="Address" required>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label for="apartment">Apartment, Suite, etc. (optional)</label>
                                                <input type="text" class="form-control" id="apartment"
                                                    name="apartment" placeholder="Apartment, suite, etc.">
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label for="city">City</label>
                                                <input type="text" class="form-control" id="city"
                                                    name="city" placeholder="City" value="Delhi"
                                                    required>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label for="state">State</label>
                                                <input type="text" class="form-control" id="state"
                                                    name="state" placeholder="state" required>
                                            </div>
                                            <div class="col-md-4 mb-3">
                                                <label for="pin_code">PIN Code</label>
                                                <input type="text" class="form-control" id="pin_code"
                                                    name="pin_code" placeholder="PIN code" required>
                                            </div>
                                        </div>
                                        <div class="row text-center">
                                            <div class="col-md-12 mb-3">
                                                <button type="submit" class="btn btn-primary">Add
                                                    Address</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                @else
                                <!-- User has saved addresses, show the select address form -->
                                <div class="col-md-12 mb-3">
                                    <form action="/payment" method="POST">
                                        @csrf
                                        <div class="card">
                                            <div class="card-header">
                                                <h5>Select Shipping Address</h5>
                                            </div>
                                            <div class="card-body">
                                                @foreach (Auth::user()->addresses as $address)
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio"
                                                        name="address_id" id="address{{ $address->id }}"
                                                        value="{{ $address->id }}" required>
                                                    <label class="form-check-label"
                                                        for="address{{ $address->id }}">
                                                        <strong>{{ $address->address }}</strong>,
                                                        {{ $address->city }}, {{ $address->country }} -
                                                        {{ $address->pin_code }}
                                                    </label>
                                                </div>
                                                <hr>
                                                @endforeach
                                            </div>
                                            <div class="card-footer">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <h6>You can also add more addresses by visiting your <a
                                                            href="/dashboard">Dashboard</a></h6>
                                                    <button type="submit" class="btn btn-primary">Proceed to
                                                        Payment</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>


                                <!-- User has saved addresses, show the select address form -->
                                <div class="col-md-12 mb-3">
                                    <form action="/cod-payment" method="POST">
                                        @csrf
                                        <div class="card">
                                            <div class="card-header">
                                                <h5>Select Shipping Address</h5>
                                            </div>
                                            <div class="card-body">
                                                @foreach (Auth::user()->addresses as $address)
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio"
                                                        name="address_id" id="address{{ $address->id }}"
                                                        value="{{ $address->id }}" required>
                                                    <label class="form-check-label"
                                                        for="address{{ $address->id }}">
                                                        <strong>{{ $address->address }}</strong>,
                                                        {{ $address->city }}, {{ $address->country }} -
                                                        {{ $address->pin_code }}
                                                    </label>
                                                </div>
                                                <hr>
                                                @endforeach
                                            </div>
                                            <div class="card-footer">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <h6>You can also add more addresses by visiting your <a
                                                            href="/dashboard">Dashboard</a></h6>
                                                    <button type="submit" class="btn btn-primary">Proceed to
                                                        COD</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                @endif
                                @else
                                <form action="/checkout" method="POST">
                                    @csrf
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label>Name <span>*</span></label>
                                            <input type="text" name="name" class="form-control"
                                                value="{{ old('name') }}" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label>Email address <span>*</span></label>
                                            <input type="email" name="email" class="form-control"
                                                value="{{ old('email') }}" required>
                                        </div>
                                        <div class="col-md-12" style="color:red;">Please enter your 10-digit phone number, excluding any country code or extension.</div>
                                        <!-- Phone Number and OTP Verification -->


                                        <div class="col-md-6 mb-3">

                                            <label for="phone">Phone <span>*</span></label>
                                            <input type="text" class="form-control"
                                                name="phone" placeholder="Phone" required>


                                        </div>
                                        <!-- <div class="col-md-6 mb-3">

                                            <label for="phone">Phone <span>*</span></label>
                                            <input type="text" class="form-control" id="phone"
                                                name="phone" placeholder="Phone" required>
                                            <button id="verify-btn" class="btn btn-primary mt-2"
                                                type="button">Verify Phone</button>
                                            <div id="message" class="my-2" style="color: green;"></div>
                                  
                                            <div id="error-message" class="my-2" style="color: red;"></div>
                                          
                                            <div id="verified-phone" class="my-2"></div>
                                       
                                        </div>

                                    
                                        <div id="otp-input" class="col-md-6 mb-3">
                                            <label for="otp">Phone Otp<span>*</span></label>
                                            <input type="text" class="form-control" name="otp"
                                                placeholder="Enter OTP" />
                                        </div> -->

                                        <!-- Other Fields -->
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label>Password <span>*</span></label>
                                                <input type="password" class="form-control" name="password"
                                                    required>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label>Confirm Password <span>*</span></label>
                                                <input type="password" class="form-control"
                                                    name="password_confirmation" required>
                                            </div>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="country">Country</label>
                                            <select class="form-control" id="country" name="country" required>
                                                <option value="India">India</option>
                                                <!-- Add more countries as needed -->
                                            </select>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="first_name">First Name (optional)</label>
                                            <input type="text" class="form-control" id="first_name"
                                                name="first_name" placeholder="First name">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="last_name">Last Name</label>
                                            <input type="text" class="form-control" id="last_name"
                                                name="last_name" placeholder="Last name" required>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label for="address">Address</label>
                                            <input type="text" class="form-control" id="address"
                                                name="address" placeholder="Address" required>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="apartment">Apartment(optional)</label>
                                            <input type="text" class="form-control" id="apartment"
                                                name="apartment" placeholder="Apartment, suite, etc.">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="city">City</label>
                                            <input type="text" class="form-control" id="city"
                                                name="city" placeholder="City" value="Delhi" required>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="state">State</label>
                                            <input type="text" class="form-control" id="state"
                                                name="state" placeholder="state" required>
                                        </div>

                                        <div class="col-md-4 mb-3">
                                            <label for="pin_code">PIN Code</label>
                                            <input type="text" class="form-control" id="pin_code"
                                                name="pin_code" placeholder="PIN code" required>
                                        </div>
                                        <div class="row">

                                            <div class="col-md-6 my-4">
                                                <button style="margin-left: 5px;" type="submit"
                                                    class="btn btn-danger">Proceed to Payment</button>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                                @endif


                            </div>
                        </div>



                    </div>
                </div>

            </div>
        </div>
    </div>


    <!--shopping cart area end -->

    @include('include/footer')
    <style>
        button:disabled {
            background-color: #cccccc;
            /* Light grey background for disabled button */
            color: #666666;
            /* Darker text color for disabled state */
            cursor: not-allowed;
            /* Shows a 'not allowed' cursor */
        }
    </style>

    <script>
        @if(!empty($cart) && $cartTotal > 0)
        const cartItems = @json($cart); // Converting the cart data into a JavaScript object
        const cartTotal = @json($cartTotal);
        const discount = @json($discount);


        let items = cartItems.map(item => ({
            item_id: item.product.id.toString(),
            item_name: item.product.product_name,
            price: item.variant ? parseFloat(item.variant.sale_price) : parseFloat(item.product.sale_price),
            quantity: item.quantity,
            variant_id: item.variant ? item.variant.id.toString() : null
        }));

        // Google Analytics `begin_checkout` event
        gtag('event', 'begin_checkout', {
            currency: 'INR', // Use INR as currency
            value: cartTotal, // Total cart value
            coupon: discount > 0 ? 'DISCOUNT_CODE' : null, // Replace with actual code if available
            items: items
        });

        // Debugging to see the generated items array
        console.log("Items for checkout:", items);
        @endif
    </script>


    <script>
        $(document).ready(function() {
            $('#otp-input').hide(); // Initially hide OTP input
            $('#checkout-submit-btn').prop('disabled', true); // Disable the submit button initially

            $('#verify-btn').on('click', function() {
                const phoneNumber = $('input[name="phone"]').val();

                if (!phoneNumber) {
                    alert('Please enter a valid phone number.');
                    return;
                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                // Send OTP
                $.ajax({
                    url: '{{ route('send-otp') }}',
                    method: 'POST',
                    data: {
                        phone: phoneNumber,
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#otp-input').show(); // Show OTP input on success
                            $('#verify-btn').text('Resend OTP');
                            $('#message').text('OTP sent successfully!').addClass(
                                'alert alert-success');
                            $('#error-message').text(''); // Clear error messages
                        } else {
                            $('#error-message').text(response.message || 'Failed to send OTP.');
                        }
                    },
                    error: function(xhr) {
                        $('#error-message').text('An error occurred while sending OTP.');
                    }
                });
            });

            // Verify OTP
            $('input[name="otp"]').on('input', function() {
                const otp = $(this).val();
                const phoneNumber = $('input[name="phone"]').val();

                if (otp.length === 6) {
                    $.ajax({
                        url: '{{ route('verify-otp') }}',
                        method: 'POST',
                        data: {
                            phone: phoneNumber,
                            otp: otp,
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            if (response.verified) {
                                $('#message').text('Phone number verified successfully!')
                                    .addClass('alert alert-success');
                                $('#otp-input').hide(); // Hide OTP input
                                $('#verify-btn').remove(); // Remove verify button

                                // Hide the phone input field
                                $('input[name="phone"]').hide();

                                // Create hidden input with verified phone number
                                $('input[name="phone"]').after(
                                    '<input type="hidden" name="phone" value="' +
                                    phoneNumber + '">');

                                // Show verified phone number
                                $('#verified-phone').html(
                                    '<div class="alert alert-info">Verified Phone Number: ' +
                                    phoneNumber + '</div>');

                                // Enable the submit button
                                $('#checkout-submit-btn').prop('disabled', false);
                            } else {
                                $('#error-message').text(response.message || 'Incorrect OTP.');
                            }
                        },
                        error: function(xhr) {
                            $('#error-message').text('An error occurred during verification.');
                        }
                    });
                }
            });
        });
    </script>

</body>

</html>